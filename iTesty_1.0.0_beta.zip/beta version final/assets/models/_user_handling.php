<?php
    const SESSION_TIMEOUT = 60 * 60;

    // Class for managing login
    class Login
    {
        public function __construct(string $username, string $password, int $uid=-1)
        {
            $this->username = $username;
            $this->password = $password;
            $this->sso = $sso;
            $this->uid = $uid;

            $this->db = $GLOBALS["db"];
        }
        
        // Gets uid by the usermail
        private function get_uid()
        {
            
            $sql = "SELECT uid FROM users WHERE usermail = :usermail";
    
            $stmt = $this->db->prepare($sql);
            if(!$stmt->execute([":usermail" => $this->username]))
            {
                return false;
            };
    
            if($row = $stmt->fetch())
            {
                $this->uid = $row["uid"];
                return true;
            }
            else
            {
                return false;
            }
            
        }

        // Compares formfield password with the one in DB
        public function verify_password()
        {
            $sql = "SELECT userpw FROM users WHERE uid= :uid";
            $stmt = $this->db->prepare($sql);
            if(!$stmt->execute([":uid" => $this->uid]))
            {
                return false;
            };

            if($row = $stmt->fetch())
            {                
                return password_verify($this->password, $row["userpw"]);
            }
            return false;
        }

        // Saves uid to the session
        private function set_session()
        {
            $_SESSION["uid"] = $this->uid;
        }

        // Sets cookie time out for specified time
        private function set_timeout_cookie()
        {
            setcookie("session_timeout", $this->uid, time() + SESSION_TIMEOUT);
        }

        // Does sign in process
        public function sign_in()
        {
            if($this->get_uid())
            {
                if($this->verify_password())
                {
                    $this->set_session();
                    return true;
                }
                return false;
            }
            return false;
        }
    }

    // Class for storing data about single users
    class User
    {
        // Constants for function get name
        public const GET_NAME_FULLNAME = 3; // Returns "fisrt-name family-name"
        public const GET_NAME_FIRST = 2; // Returns "fisrt-name"
        public const GET_NAME_FAMILY = 1; // Returns "family-name"

        // Error types for change_password()
        public const ERR_PASSWORD_VERIFY = 0; // Returns error when current-pw verification fails
        public const ERR_PASSWORD_CHANGE = -1; // Returns error when the whole process fails

        public function __construct(int $uid)
        {
            $this->uid = $uid;
            $this->db = $GLOBALS["db"];

            $this->load_data();
        }

        // Loads data about user from the DB
        private function load_data()
        {
            $sql = "SELECT usermail, first_name, family_name, time_created, time_edited, gid, iid, ban FROM users WHERE uid = :uid";
            $stmt = $this->db->prepare($sql);
            if(!$stmt->execute([":uid" => $this->uid]))
            {
                raise_error(ERROR_DB_QUERY_FAIL);
            }
            if($row = $stmt->fetch(PDO::FETCH_ASSOC))
            {
                $this->username = $row["usermail"];
                $this->time_created = $row["time_created"];
                $this->name["first_name"] = $row["first_name"];
                $this->name["family_name"] = $row["family_name"];
                $this->gid = (int) $row["gid"];
                $this->iid = (int) $row["iid"];
                $this->ban = (bool) $row["ban"];
                return true;
            }
            raise_error("No user found");
        }

        // Function for rendering user's true name
        public function get_name(int $mode) :string
        {
            switch($mode)
            {
                case $this::GET_NAME_FAMILY:
                $toReturn = $this->name["family_name"];
                break;

                case $this::GET_NAME_FIRST:
                $toReturn = $this->name["first_name"];
                break;

                case $this::GET_NAME_FULLNAME:
                $toReturn = $this->name["first_name"]. " " . $this->name["family_name"];
                break;

                default:
                $toReturn = (string) null;
                break;
            }

            return $toReturn;
        }

        // Changes users password. Returns int as a number of error
        public function change_password(string $old_password, string $new_password) : int
        {
            $verificator = new Login($this->username, $old_password, $this->uid);
            if(!$verificator->verify_password())
            {
                return $this::ERR_PASSWORD_VERIFY;
            }
            
            $new_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET :userpw = :password WHERE uid = :uid";
            $stmt = $this->db->prepare($sql);
            if(!$stmt->execute([":userpw" => $new_password, ":uid" => $this->uid]))
            {
                return $this::ERR_PASSWORD_CHANGE;
            }
            return 1;            
        }
    }

    
