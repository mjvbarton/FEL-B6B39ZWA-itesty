<?php
    
    // Checking the availability of DB
    $db = isset($GLOBALS["db"]) ? $GLOBALS["db"] : null;
    if(!isset($db))
    {
        raise_error("Databáze nenalezena.");
    }

    // Inserts question to database with valid data
    function insertQuestion(int $sid, int $toid, int $creator, string $heading, string $description, 
    string $answer_type, array $answers, int $answer_right, int $isPublic)
    {
        // Parse answers
        $answers_to_insert = array();
        $i = 0;
        foreach($answers as $answer)
        {
            if(!$answer)
            {
                break;
            }
            $answers_to_insert[$i] = $answer;
            $i++;
        }
        $answers = $answers_to_insert;

        // Create question row in table
        $sql = "INSERT INTO questions (toid, creator_uid, heading, description, answer_type, answer_right, answer_count, public) 
        VALUES(:toid, :creator, :heading, :description, :answer_type, :answer_right, :answer_count, :public)";
        $db = $GLOBALS["db"];
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);

        $stmt = $db->prepare($sql);

        $data = [
            ":toid" => $toid,
            ":creator" => $creator,
            ":heading" => $heading,
            ":description" => $description,
            ":answer_type" => $answer_type,
            ":answer_right" => $answer_right,
            ":answer_count" => count($answers),
            ":public" => $isPublic
        ];
        if(!$stmt->execute($data))
        {
            raise_error(ERROR_DB_QUERY_FAIL);
        };
        
        // Get qid after insertion
        $sql = "SELECT LAST_INSERT_ID()";
        $stmt = $db->query($sql);
        $qid = (int) $stmt->fetch()[0];
        
        // Inserting answers
        $counter = 1;
        foreach($answers as $answer)
        {
            insertAnswer($qid, $counter, $answer);
            $counter++;
        }
        
    }

    // Inserts answers to question in DB by qid
    function insertAnswer(int $qid, int $counter, string $answer_data)
    {
        // Skips insert if no data
        if(!$answer_data)
        {
            return;
        }

        // Load data
        $db = $GLOBALS["db"];
        $sql = "UPDATE questions SET answer$counter = :answer_data WHERE qid = $qid";
        $stmt = $db->prepare($sql);
        $data = [
            ":answer_data" => $answer_data
        ];
        if($stmt->execute($data))
            {
                $stmt->closeCursor();
                return true;
            }
        else
        {
            $stmt->closeCursor();
            return false;
        }       
    }