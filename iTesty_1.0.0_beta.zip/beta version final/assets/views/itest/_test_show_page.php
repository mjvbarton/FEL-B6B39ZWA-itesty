<?php 
include("views/itest/_question_formfields.php");
include("views/itest/_controlpanel.php");
include("views/static/_header.php");

function get_time_limit($itest)
{
    if($itest->time_limit)
    {
        echo "je <strong>30 min</strong>";
    }
    else
    {
        echo "<strong>není</strong>";
    }
}

?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    
    <title>iTesty</title>
    <link rel="stylesheet" href="/resources/css/main.css" media="screen">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/resources/css/print.css" media="print">
    
</head>

<body>
    <!-- Top menu bar -->
    <?php get_header("_topmenu-user") ?>
    
    <!-- Side menubar -->
    <nav id="sidebar-left">
<?php
    control_panel_show_mode($itest);
?>
        <hr class="hide-separator" />
    </nav>

    <!-- Header of current page (used for printing purposes) -->
    
    <header>
        <h1><?php echo "{$itest->subject->name} - {$itest->topic->name}"; ?></h1>
        <hr class="hide-separator" />
    </header>

    <!-- Page content -->

    <div id="page">

        <!-- Test information -->

        <section id="itest-head">
            <h2><?php echo "{$itest->topic->name} ({$itest->topic->class}. ročník)"; ?></h2>
            <p>V tomto testu je <strong><?php echo $itest->question_count; ?> otázek</strong> a časový limit na řešení testu <?php get_time_limit($itest); ?>.</p>
            <hr class="hide-separator" />
        </section>
        <section id="itest-body">
            <form id = "itest-form" action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
            
<?php
    $questionData = $itest->questions;

    $select_question = $questionData->pop();
    if(!$select_question) {
        ?>
            <div><strong>Chyba</strong>&nbsp;Nenalezeny žádné otázky.</div>
<?php
    }
    $q = 1; //Question counter
    while($select_question){

        renderQuestion($q, $select_question->data);
        $select_question = $questionData->pop();
        $q++;       
    }
    ?>
    <input type="hidden" name="count-questions" value="<?php echo $q - 1; ?>" />
    <input type="hidden" name="teid" value="<?php echo $itest->teid; ?>" />
            </form>
            <hr class="hide-separator" />
        </section>
    </div>

    <!-- Footer -->

    <footer id="bottombar">
    <?php include("views/static/_footer.php"); ?>
    </footer>
</body>
</html>