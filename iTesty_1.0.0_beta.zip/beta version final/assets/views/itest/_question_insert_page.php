<?php
    include("views/itest/_question_formfields.php");
    include("views/itest/_controlpanel.php");
    include("views/static/_header.php");
    include_once("lib/_status-box.php");
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    
    <title>iTesty</title>

    <link rel="stylesheet" href="/resources/css/main.css" media="all">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/resources/css/noprint.css" media="print">

    <script src="/resources/js/ajax/topic_filter.js"></script>
    <script src="/resources/js/control/question_insert.js"></script>
    <script src="/resources/js/misc/error_rendering.js"></script>
    <script src="/resources/js/misc/answer_type.js"></script>
    <script src="/resources/js/misc/form_functions.js"></script>
</head>

<body>

    <!-- Top menu bar -->

    <?php get_header("_topmenu-user"); ?>
    

    <!-- Header of current page -->

    <header>
        <h1>Test</h1>
        <hr class="hide-separator" />
    </header>

    <!-- Page content -->

    <div id="page" class="no-sidebar">
    <section id="itest-head">
            <h2>Přidat otázku</h2>
            <p>Pomozte komunitě iTestů rozšířit možnosti testování. Zásady správného přidávání otázek naleznete <strong><a href="/help/07" target="_blank">zde</a></strong>
            </p>
            <?php
                statusbox_from_session();
            ?>
            <hr class="hide-separator" />
        </section>
        <section id="itest-body">
            <h2 class="hide-me">Obsah otázky</h2>
            <form action="/question/insert" id="question_insert" method="post">
                <?php 
                    renderQuestionInsertionParams($formfields, $subject);
                    renderQuestionInsertion($formfields, $subject);                     
                ?>
            </form>
            <hr class="hide-separator" />
        </section>
    </div>

    <!-- Footer -->

    <footer id="bottombar">
    <?php include("views/static/_footer.php"); ?>
    </footer>

    <script>
        <!--
        load();
        -->
    </script>
</body>
</html>