<?php 
include("views/itest/_question_formfields.php");
include("views/itest/_controlpanel.php");
include("views/static/_header.php");

function get_time_limit($itest)
{
    if($itest->time_limit)
    {
        echo "je <strong>30 min</strong>";
    }
    else
    {
        echo "<strong>není</strong>";
    }
}

?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    
    <title>iTesty</title>

    <link rel="stylesheet" href="/resources/css/main.css" media="all">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/resources/css/print.css" media="print">

    <script src="/resources/js/control/itest.js"></script>
    <script src="/resources/js/misc/form_functions.js"></script>
</head>

<body>
    <!-- Top menu bar -->
    <?php get_header("_topmenu-itest"); ?>
    
    <!-- Side menubar -->
    <nav id="sidebar-left">
<?php
    control_panel_fill_mode($itest);

?>
        <hr class="hide-separator" />
    </nav>

    <!-- Dialog to be handled by Javascript -->

    <dialog id="itest-dialog" class="formfield dialog">
        <h3>Zkontrolovali jste si své odpovědi?</h3>    
        <p>Některé otázky možná zůstaly nezodpovězeny a jinde jste možná udělali chybu z nepozornosti.</p>
        <p>Opravdu chcete vyhodnotit váš test?</p>
        <div class="formfield dialog-buttons">
            <form method="dialog">
                <button id="dialog-submit" class="formfield btn btn-submit" value="submit"><i class="fa fa-check"></i>&nbsp;Ano</button><!--</label>-->
                <button id="dialog-reject" class="formfield btn btn-quit" value="reject"><i class="fa fa-close"></i>&nbsp;Ne</button>
            </form>
        </div>
    </dialog>

    <!-- Header of current page (used for printing purposes) -->
    
    <header>
        <h1><?php echo "{$itest->subject->name} - {$itest->topic->name}"; ?></h1>
        <hr class="hide-separator" />
    </header>

    <!-- Page content -->

    <div id="page">

        <!-- Test information -->

        <section id="itest-head">
            <h2><?php echo "{$itest->topic->name} ({$itest->topic->class}. ročník)"; ?></h2>
            <p>V tomto testu je <strong><?php echo $itest->question_count; ?> otázek</strong> a časový limit na řešení testu <?php get_time_limit($itest); ?>.</p>
            <strong id="noJScript">Pečlivě si zkontrolujte odpovědi, než kliknete na tlačítko vyhodnotit.</strong>
            <hr class="hide-separator" />
        </section>
        <section id="itest-body">
            <form id = "itest-form" action="/test/fill/<?php echo $itest->teid;?>" method="post" data-question-count="<?php echo htmlspecialchars($itest->question_count); ?>" data-answers-max="<?php //echo (string) ITEST_MAX_ANSWERS_ALLOWED; ?>">
            
<?php
    $questionData = $itest->questions;

    $select_question = $questionData->pop();
    if(!$select_question)
    {
        $statusBox = new StatusBox("Nenalezeny žádné otázky", STATUSBOX_TYPE_WRONG);
        $statusBox->show();
        
    }
    $q = 1; //Question counter
    while($select_question){

        renderQuestion($q, $select_question->data);
        $select_question = $questionData->pop();
        $q++;       
    }
    ?>
    <input type="hidden" name="count-questions" value="<?php echo $q - 1; ?>" />
    <input type="hidden" name="teid" value="<?php echo $itest->teid; ?>" />
            </form>
            <hr class="hide-separator" />
        </section>
    </div>

    <!-- Footer -->
    <footer id="bottombar">
    <?php include("views/static/_footer.php"); ?>
    </footer>

    <script>
        <!--
        load();
        -->
    </script>
</body>
</html>