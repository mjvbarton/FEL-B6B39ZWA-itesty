<?php
    const CSS_QUESTION_CORRECT = "success"; // contains name of css class for correct answer
    const CSS_QUESTION_WRONG = "wrong"; // contains name of css class for unfilled or wrong answer
    const MSG_QUESTION_WRONG = "Správná odpověď:"; // Contains message for wrong test question
    const ANSWER_TYPE_TEXT = "text"; // Answer type text
    const ANSWER_TYPE_OPTTEXT = "opt_text"; // Answer type option with text
    const ITEST_MAX_ANSWERS_ALLOWED = 5; // Max number of answers which itest can contain

    // Checks evaluated radio input if it was checked in the test
    function checkOption( $answer){
        if($answer->checked){
            return "checked ";
        }
    }

    // Gets error message from fieldlist of formfields
    function get_error( $formfields, string $name)
    {
        if($formfields->field($name))
        {
            return $formfields->field($name)->get_error();
        }
        else
        {
            return null;
        }
    }

    // Shows error message in <span> at the formfield
    function showErrorMessage($msg)
    {
        if($msg)
        {
            return "<span class='formfield message-box'>$msg</span>";
        }
        return "";
    }

    // Shows answer input according to the answer_type for the question insert
    function showInsertAnswerOptions()
    {
        $classlist = [
            "text" => "hide-me",
            "opt_text" => "hide-me",
            "buttons" => "hide-me"
        ];
        
        if(isset($_POST['answer_type']))
        {
            $classlist["buttons"] = "";
            switch($_POST["answer_type"])
            {
                case "text":
                    $classlist["text"] = "";
                    break;

                case "opt_text":
                    $classlist["opt_text"] = "";
                    break;
            }
        }
        return $classlist;
    }

    // Check if insert selector option is selected
    function checkInsertSelectorOption($answerShowResult)
    {
        if(!$answerShowResult)
        {
            echo "selected";
        }
        else
        {
            echo "";
        }
    }

    // Returns css class based on answers->isCorrect
    function getCssClassOfAnswer( $answer){
        if($answer->isCorrect == 1) {
            return CSS_QUESTION_CORRECT;
        }
        elseif($answer->isCorrect == 0) {
            return CSS_QUESTION_WRONG;
        }
        else{
            return "";
        }
    }

    // Renders question (decides which type based on question->answer_type)
    function renderQuestion(int $counter,  $question){
        if($question->answer_type == ANSWER_TYPE_TEXT){
            renderQuestionTypeText($counter, $question);
        }
        elseif($question->answer_type == ANSWER_TYPE_OPTTEXT){
            renderQuestionTypeOptText($counter, $question);
        }
        else{
            die("Error: Invalid question type.");
        }
    }

    // Renders question with text field
    function renderQuestionTypeText(int $counter,  $question) {
        $answer = $question->answers[1];
        ?>
        <fieldset class="itest option">
            <div class="itest option toolbar">
            </div>
            <input type="hidden" name="<?php echo "qid".$counter; ?>" value = "<?php echo $question->qid; ?>">
            <h3><strong>Otázka č. <?php echo $counter; ?></strong>&nbsp;-&nbsp;<?php echo $question->head; ?></h3>
            <p><?php echo $question->desc; ?></p>
            <label class="formfield important-label <?php echo getCssClassOfAnswer($answer);?>">
                Odpověď:
                <input id="<?php echo "question-$counter-answer-1"; ?>" type="text" autocomplete="off" name="<?php echo "answer".$question->qid; ?>" class="formfield text-input" value="<?php echo htmlspecialchars($question->usr_answer);?>" <?php echo $question->blockFormInput(); ?>>
            </label>
            <span class="formfield wrong correct"><?php if($answer->isCorrect==0) {echo "Chybná odpověď. Správně je <strong>$answer->text</strong>";} ?></span>
        </fieldset>
<?php
    }

    // Render question with radios. Values at the radios are text.
    function renderQuestionTypeOptText(int $counter,  $question) {
        ?>
        <fieldset class="itest option">
            <div class="itest option toolbar">
            </div>
            <input type="hidden" name="<?php echo "qid".$counter ?>" value = "<?php echo $question->qid; ?>">
            <h3><strong>Otázka č. <?php echo $counter; ?></strong>&nbsp;-&nbsp;<?php echo $question->head; ?></h3>
            <p><?php echo $question->desc; ?></p>
            <p><label class="formfield important-label radio-box-caption <?php echo getCssClassOfAnswer($question);?>">Odpověď:</label></p>
            
            <div class="itest radio-box">
                <input type="hidden" name="<?php echo "answer".$question->qid; ?>" value="0">
                <ol>
                    <?php for($i = 1; $i <= count($question->answers); $i++) {
                        $answer = $question->answers[$i];
                        ?>
                    <li>
                        
                        <label class="formfield radio-field <?php echo getCssClassOfAnswer($answer); echo " ".checkOption($answer);?> "><?php echo $answer->text; ?>
                            <input id="<?php echo "question-$counter-answer-$i"; ?>" type="radio" name="<?php echo "answer".$question->qid; ?>" value="<?php echo $i; ?>" <?php echo checkOption($answer); echo $question->blockFormInput(); ?>>
                            <span class="checkmark radio-input <?php echo getCssClassOfAnswer($answer);?>"></span>
                        </label>
                    </li>
                    <?php } ?>
                </ol>
            </div>
        </fieldset>

<?php    
    }

    // Renders formfield for inserting new question to the DB
    function renderQuestionInsertion( $formfields)
    {
?>      
        <fieldset class="itest option" id="q1">
                    <div class="itest option toolbar">
                        <a href="/help/06"><i class="fa fa-question"></i>&nbsp; <span class="hide-description">Nápověda</span></a>
                    </div>
                    <label>
                        <span class="hide-me">Nadpis otázky</span>
                        <input type="text" name="caption" class="formfield insert caption" maxlength="50" autocomplete="off" placeholder="Text otázky" value="<?php echo isset($_POST["caption"]) ? htmlspecialchars($_POST["caption"]) : "";?>" <?php echo !$formfields->field("sidselect") ? "" : "required"; ?>>                    
                        <?php echo (get_error($formfields, "caption")) ? showErrorMessage(get_error($formfields, "caption")) : ""; ?>
                    </label>
                    <label>
                        <span class="hide-me">Popis otázky (volitelné)</span>
                        <textarea name="description" class="formfield insert description" cols="100" rows="3" maxlength="150" placeholder="Doplňující informace k otázce (nepovinné)"><?php if(isset($_POST["description"])) { echo htmlspecialchars($_POST["description"]); } ?></textarea>
                        <?php echo (get_error($formfields, "description")) ? showErrorMessage(get_error($formfields, "description")) : ""; ?>
                    </label>

                    <!-- Type of answer selection -->

                    <div id="qSelect">
                        <label class="formfield important-label">Typ odpovědi:
                            <select name="answer_type" class="formfield select">
                                <option value="0" selected disabled>vyberte se seznamu</option>
                                <option value="text" <?php checkInsertSelectorOption(showInsertAnswerOptions()["text"]); ?>>Otevřená odpověď (textové pole)</option>
                                <option value="opt_text" <?php checkInsertSelectorOption(showInsertAnswerOptions()["opt_text"]); ?>>Uzavřená úloha</option>
                                <option value="opt_img" disabled>Uzavřená úloha s obrázky</option>
                            </select>
                        </label>
                        <button id="q1select_noJS" type="submit" form="question_insert" name="rerender" value="rerender" class="formfield btn"><i class="fa fa-refresh">&nbsp;</i><span class="hide-me">Obnovit</span></button>
                    </div>

                    <!-- Question type 'text' -->
                    <div id="qText" class="<?php echo showInsertAnswerOptions()["text"]; ?>">
                        <label class="formfield important-label success">
                            Odpověď:
                            <input type="text" name="answer1" class="formfield text-input" maxlength="25" autocomplete="off">
                        </label>
                        <?php echo (get_error($formfields, "answer1")) ? showErrorMessage(get_error($formfields, "answer1")) : ""; ?>
                    </div>

                    <!-- Question type 'opt_text' -->
                    <div id="qOptText" class="<?php echo showInsertAnswerOptions()["opt_text"]; ?>">
                        <h4><span id="answer-right-indicator" title="Prosím, zaškrtněte správnou odpověď">Odpověď:</span><?php echo (get_error($formfields, "answer_right")) ? showErrorMessage(get_error($formfields, "answer_right")) : ""; ?></h4>
                        <div class="itest radio-box insert">
                            <input type="hidden" name="answer_right" value="-1" />
                            <ol>
                                <?php
                                    for($i = 1; $i <= ITEST_MAX_ANSWERS_ALLOWED; $i++)
                                    {
                                ?>
                                <li>
                                    <label class="formfield radio-field">&nbsp;
                                        <input type="radio" id="<?php echo "answer-right-$i"; ?>" name="answer_right" value="<?php echo $i; ?>"><span class="checkmark radio-input"></span>
                                    </label>
                                    <label>
                                        <span class="hide-me">Text odpovědi:</span>
                                        <input type="text" id="<?php echo "answer-$i";?>" name="answers[]" class="formfield insert answer" maxlength="50" autocomplete="off" placeholder="možnost <?php echo $i; ?>" 
                                        value="<?php echo isset($_POST["answers"][$i - 1]) ? $_POST["answers"][$i - 1] : ""; ?>"/>
                                        <?php echo (get_error($formfields, "answer$i")) ? showErrorMessage(get_error($formfields, "answer$i")) : ""; ?>
                                    </label>
                                </li>
                                <?php
                                    }
                                ?>
                            </ol>
                        </div>
                    </div>

                    <div id="qButtons" class="<?php echo showInsertAnswerOptions()["buttons"] ?>">
                        <!-- This will add new question and will display the same page for a new question in the same topic -->
                        <button type="submit" form="question_insert" name="addQuestion" value="2" class="formfield btn btn-submit"><i class="fa fa-plus-circle">&nbsp;</i>Uložit a přidat další</button>

                        <!-- This will add new question and will redirect to last wizard position -->
                        <button type="submit" form="question_insert" name="addQuestion" value="1" class="formfield btn btn-submit"><i class="fa fa-check">&nbsp;</i>Uložit</button>
                    </div>
                </fieldset>
<?php
    }
    
    // Renders parameters for question insertion 
    function renderQuestionInsertionParams( $formfields, $subject = null)
    {
?>
<fieldset id="question-insert-params" class="itest option">
    <h3>Parametry otázky</h3>
    
    <!-- Subject selection -->
    <div>
        <input type="hidden" id="sid" name="sid" value="-1">
        <label class="formfield important-label">
            Předmět:
            <input type="text" id="sidselect" name="sidselect" list="sidselect_data" form="question_insert" class="formfield text-input small" maxlength="25" autocomplete="off" 
                value='<?php echo !isset($_POST["sidselect"]) || (!$_POST["sidselect"]) || (!$formfields->field("sidselect")) ? "" : $formfields->field("sidselect")->get_value(); ?>' required>
            <?php echo showErrorMessage(!$formfields->field("sidselect") ? "" : $formfields->field("sidselect")->get_error()); ?>
        </label>
    </div>
    
    <!-- Subject datalist -->

    <datalist id="sidselect_data">            
        <?php
            $subjects = new iTestSubjectContainer;
            if($subjects->subjects)
            {
                foreach($subjects->subjects as $subj)
                {
                    echo "<option value='$subj->name'>";
                }
            }
        ?>
    </datalist>

    <!-- Topic selection -->
    
    <div>
        <input type="hidden" id="toid" name="toid" value="-1">        
        <label class="formfield important-label">
            Téma:
            <input type="text" id="toidselect" name="toidselect" list="toidselect_data" form="question_insert" class="formfield text-input small" autocomplete="off" maxlength="25" value="<?php echo !isset($_POST["toidselect"]) || (!$_POST["toidselect"]) || (!$formfields->field("toidselect")) ? "" : $formfields->field("toidselect")->get_value(); ?>"
            <?php echo !$formfields->field("sidselect") ? "" : "required"; ?>>
            <?php echo showErrorMessage(!$formfields->field("toidselect") ? "" : $formfields->field("toidselect")->get_error()); ?>
        </label>
    </div>
                
    <!-- Topic datalist -->     
                    
    <datalist id="toidselect_data">
        <?php
            if(isset($subject))
            {
                foreach($subject->get_topics() as $topic)
                {
                    echo "<option value='$topic->name'>";
                }
            }
        ?>
    </datalist>
</fieldset>
<?php
    }