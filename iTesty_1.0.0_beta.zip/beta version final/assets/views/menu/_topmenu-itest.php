<li></li>
<li><a href="/help"><i class="fa fa-question-circle">&nbsp;</i>Nápověda</a></li>