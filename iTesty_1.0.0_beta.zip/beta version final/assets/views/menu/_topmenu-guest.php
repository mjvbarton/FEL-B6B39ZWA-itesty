<li><a href="/"><i class="fa fa-sign-in">&nbsp;</i>Přihlásit se</a></li>
<li><a href="/help"><i class="fa fa-question-circle">&nbsp;</i>Nápověda</a></li>