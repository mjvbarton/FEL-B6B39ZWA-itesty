<li><a href="/test" class="vis-logon"><i class="fa fa-pencil">&nbsp;</i>Psát test</a></li>
<li><a href="/user/tests" class="vis-logon"><i class="fa fa-graduation-cap">&nbsp;</i>Napsané testy</a></li>
<li><a href="/question/insert" class="vis-logon"><i class="fa fa-plus-circle">&nbsp;</i>Vytvořit otázky</a></li>
<li><a href="/user/profile" class="vis-logon"><i class="fa fa-user-circle">&nbsp;</i>Můj profil</a></li>
<li><a href="/help" class="vis-guest"><i class="fa fa-question-circle">&nbsp;</i>Nápověda</a></li>
<li><a href="/user/logout" class="vis-logon"><i class="fa fa-sign-out">&nbsp;</i>Odhlásit se</a></li>