<?php

// This is view which shows you written tests

    // Including necessary views with functions
    include("views/static/_header.php");
    include("views/misc/_pagination.php");
    include("views/misc/_rendering_helpers.php")
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    
    <title>iTesty - Nápověda</title>

    <link rel="stylesheet" href="/resources/css/main.css" media="all">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="resources/css/print.css" media="print">
    
</head>

<body>

    <!-- Top menu bar -->
    <?php 
        $type = isset($_SESSION["uid"]) ? ACCESS_USER_COMMON : ACCESS_GUEST;
        get_header("_topmenu-$type"); ?>
    

    <!-- Side menubar -->

    <nav id="sidebar-left">
        <div class="sidebar-left menu-left">
            <?php include_mdfile(HELP_CONTENT_FILE.".md"); ?>
        </div>
        <hr class="hide-separator" />
    </nav>
    
    <!-- Header of current page -->

    <header>
        <h1>Homepage</h1>
        <hr class="hide-separator" />
    </header>

    <!-- Page -->

    <main id="page">

        <!-- Help content section -->

        <section id="help-content">
            <?php include_mdfile("help/".$content_file.".md"); ?>
            <hr class="hide-separator" />
        </section>
        <hr class="hide-separator" />
    </main>

    <!-- Footer -->

    <footer id="bottombar">
        <?php include("views/static/_footer.php"); ?>
    </footer>
</body>
</html>