<?php

// This is view which shows you written tests

    // Including necessary views with functions
    include("views/static/_header.php");
    include("views/misc/_pagination.php");
    include("views/misc/_rendering_helpers.php")
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    
    <title>iTesty - Můj profil</title>

    <link rel="stylesheet" href="/resources/css/main.css" media="all">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--<link rel="stylesheet" href="resources/css/print.css" media="print">-->
    
</head>

<body>

    <!-- Top menu bar -->

    <nav class="menu-top" id="topbar">
        <?php get_header("_topmenu-user") ?>;
    </nav>
    
    <!-- Header of current page -->

    <header>
        <h1>Homepage</h1>
        <hr class="hide-separator" />
    </header>

    <!-- Page -->

    <main id="page" class="no-sidebar">

        <!-- Profile information -->

        <section id="user-profile">
            <h2>Můj profil</h2>
            <?php 
                statusBox_from_session();
            ?>
            <div id="profile-container" class="itest option single-profile">
                <div class="profile profile-photo">
                    <img alt="profile photo" src="/resources/img/profiles/default.png">
                </div>

                <div class="profile profile-details">
                    <h3><?php echo htmlspecialchars($user->get_name(User::GET_NAME_FULLNAME)); ?></h3>
                    <table>
                        <tr>
                            <th>Email:</th>
                            <td><?php echo htmlspecialchars($user->username); ?></td>
                        </tr>

                        <tr>
                            <th>Přidán:</th>
                            <td><?php echo get_time_created($user); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <hr class="hide-separator">
        </section>
    </main>

    <!-- Footer -->

    <footer id="bottombar">
        <?php include("views/static/_footer.php"); ?>
    </footer>
    <script>load();</script>
</body>
</html>