<?php

    include_once("models/_test_handling.php");

    // Getting teid from url
    $teid = isset($todo[3]) && ((int) $todo[3]) ? (int) $todo[3] : null;
    
    // Rejecting test if rejected
    if(isset($_POST["reject-test"]))
    {
        add_statusbox_to_session(STATUSBOX_TYPE_DEFAULT, "Test můžete nalézt v záložce <em>Napsané testy</em>");
        header("Location: /");
        exit();
    }

    // Form evaluation
    if(isset($_POST['submit-test'])) {

        if(isset($_POST['count-questions']))
        {
            $teid = $_POST['teid'];
            $itest = new iTest($teid);
            if(!$itest->evaluated)
            {           
                $count_questions = $_POST['count-questions'];
                $usr_answers = array();
                for($pointer = 1; $pointer <= $count_questions; $pointer++)
                {
                    $qid = $_POST["qid".$pointer];
                    if(isset($_POST["answer".$qid]))
                    {
                        $usr_answers["q$qid"] = trim($_POST["answer".$qid]);
                    }
                    else
                    {   
                        $usr_answers["q$qid"] = null;
                    }
                }
                $itest = new iTest($teid);
                $itest->evaluate($usr_answers);
                $itest->save_data();                
            }
            header("Location: /test/show/$teid");
            exit();
            
        }
    }

    // Checking if the test was filled
    elseif((isset($teid)) && ($itest = new iTest($teid)))
    {
        if(!$itest->evaluated)
        {
            include_once("views/itest/_test_fill_page.php");
            exit();
        }
        header("Location: /test/show/$teid");
        exit();
    }
    else
    {
        add_statusbox_to_session(STATUSBOX_TYPE_WRONG, "Test nebyl nalezen");
        header("Location: /test");
        exit();
    }

    