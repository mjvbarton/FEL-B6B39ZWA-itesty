<?php
    include_once("models/_test_handling.php");

    $toid = (int) $_POST["toid"][1];
    $question_count = (int) $_POST["question_count"];

    $testgen = new iTestGenerator($toid, (int) $_SESSION["uid"], $question_count);
    if($teid = $testgen->generate())
    {
        header("Location: /test/fill/$teid");
        exit();
    }
    else
    {
        error_raise(ERROR_TEST_CREATE_FAIL);
    }