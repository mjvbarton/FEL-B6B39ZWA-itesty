<?php
    const HELP_CONTENT_FILE = "help-content";
    const HELP_DEFAULT = "01";

    // Gets help content by paramters from URI
    function get_help_content(string $content_file)
    {
        if((!$content_file) || ($content_file == "action_default"))
        {
            header("Location: /help/".HELP_DEFAULT);
            exit();
        }
        if(file_exists($path = DOCUMENT_ROOT.MDFILES_STORAGE."help/".$content_file.".md"))
        {
            include("views/static/_view_help.php");
        }
    }