<?php
    // Redirects to question insert
    function action_default(array $todo)
    {
        header("Location: /question/insert");
        exit();
    }

    function insert(array $todo)
    {
        include("control/question/insert.php");
    }