<?php
    include_once("models/_subject_handling.php");
    include_once("models/_topic_handling.php");

    $subjects = new iTestSubjectContainer();
    $validSubject = false;
    $validTopic = true;

    // Validation of the subject
    if(isset($_GET["sidselect"]))
    {
        $subject = $subjects->subject($_GET["sidselect"]);
        if($subject)
        {
            $_GET["sid"] = trim($subject->sid);
            $validSubject = True;
        }
        else
        {
            $validSubject = False;
        }
    }
    
    if(isset($_GET["toname"]))
    {
        if(($validSubject)&& ($x = $subjects->subject(trim($_GET["sidselect"]))->get_topic_by_name(trim($_GET["toname"]))))
        {
            $validTopic = True;
        }
        else
        {
            $validTopic = False;
        }
    }


    // $_GET parameters validation
    $filter_params = readGetParams();

    // Get data
    $topicFilter = new iTestTopicFilter($filter_params);
    $topicFilter->enable_pagination();
    $topicFilter->load_topics();

    // Parse topic names data to array
    $returnTopics = array();
    foreach($topicFilter->topics as $topic)
    {
        $returnTopics[] = htmlspecialchars($topic->name);
    }

    $result = [      
                "topics" => $returnTopics,
                "validSubject" => $validSubject,
                "validTopic" => $validTopic,
                "empty" => $topicFilter->empty
            ];
    
    echo json_encode($result);




