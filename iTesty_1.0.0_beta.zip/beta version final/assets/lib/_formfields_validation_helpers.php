<?php

    // Checks if topic object with name of formfield is in the subject in subject formfield
    function formfields_validate_topic_in_subject( $formfields, $subject)
    {
        if(($toname = $formfields->field("toidselect")) && ($subject))
        {
            if($subject->get_topic_by_name((string) $toname->get_value(false)))
            {
                return true;
            }
            return false;
        }
        return false;
    }

    // This function validates if subject extracted from formfield exists
    function formfields_validate_existing_subject( $formfields,  $subjects)
    {
        if(($suname = $formfields->field("sidselect")) && ($subjects))
        {
            if($subjects->subject((string) $suname->get_value(false)))
            {
                return true;
            }
            return false;
        }
        return false;
    }

    // This function validates if password formfield contains upper case, lower case and numbers
    function formfield_validate_password($formfield) : bool
    {   
        if(!$formfield->validate_pattern("^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).*$^"))
        {
            $formfield->custom_error_msg("Zadané heslo musí obsahovat malá písmena, velká písmena a číslici");
            return false;
        }
        return true;
    }