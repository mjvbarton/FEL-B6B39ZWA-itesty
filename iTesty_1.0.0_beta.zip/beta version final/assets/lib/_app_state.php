<?php
const ERROR_DB_NOT_FOUND = "Databáze nenalezena"; // Error message db connection failure
const ERROR_DB_QUERY_FAIL = "Připojování k databázi selhalo"; // Error message for wrong query
const ERROR_WRONG_DATA_FORMAT = "Špatný formát dat"; // Error message for wrong data format
const ERROR_TEST_NOT_FOUND = "Hledaný test nebyl nalezen"; // Error message if the searched test was not found

// Saves current subject name and current topic name to session
function preserve_subject_topic_isPublic(string $subject_name, string $topic_name, string $isPublic)
{
    $_SESSION["last_subject"] = $subject_name;
    $_SESSION["last_topic"] = $topic_name;
    $_SESSIOn["last_isPublic"] = $isPublic;
}

// Gets statusbox from value in session (special string format required)
function statusbox_from_session($preserve_session = false)
{
    if((isset($_SESSION["statusbox"])) && ($_SESSION["statusbox"]))
    {
        $status = explode(STATUSBOX_TEXT_DELIMITER, $_SESSION["statusbox"]);
        $statusBox = new StatusBox($status[1], $status[0]);
        $statusBox->show();
        if(!$preserve_session)
        {
            $_SESSION["statusbox"] = "";
        }
    }
}

// Save statusbox data to session in special string format
function add_statusbox_to_session(string $type, string $message)
{
    if(($type) && ($message))
    {
        $_SESSION["statusbox"] = $type.STATUSBOX_TEXT_DELIMITER.$message;
    }
}

// This raises error and redirects to homepage
function raise_error($msg)
{
    add_statusbox_to_session(STATUSBOX_TYPE_WRONG, $msg);
    header("Location: /");
    exit();
}