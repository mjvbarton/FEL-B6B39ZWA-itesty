*iTesty* jsou novou alternativní platformou pro vzdělávání. Jsou koncipovány jako podpůrná aplikace pro výuku nejrůznějších předmětů. Obsah tvoří komunita uživatelů, která si vytváří testové otázky, které mezi sebou sdílí.

![alt text](/resources/img/help/itesty_question_insert.png "iTesty - princip vkládání otázek")

Z těchto otázek pak aplikace některé náhodně vybírá podle uživatelem definovaných parametrů (předmět, tématický okruh, počet otázek) a sestavuje z nich testy, které si může uživatel vyplnit. Aplikace je pak vyhodnotí a umožní uživateli, aby si zobrazil svojí historii.

<a class="formfield btn" href="/help/01"><i class="fa fa-info">&nbsp;</i> Více informací</a>