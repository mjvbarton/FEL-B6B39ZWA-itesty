// Setting up Javascript environment
// This will update datalist at #search_topic
// It uses function topic filter for communicating with the API
function load()
{
    var toidselect = document.querySelector("#search_topic");
    toidselect.addEventListener("keyup", get_topics);
}