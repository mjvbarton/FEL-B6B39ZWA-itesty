// Sets up Javascript environment
function load()
{
    var form = document.querySelector("#itest-form");
    form.setAttribute("novalidate", "novalidate");
    form.addEventListener("submit", validate_itest_form);

    var hide_warning = document.querySelector("#noJScript");
    hide_warning.classList.add("hide-me");

    var close = document.querySelector("#itest-form-reject");
    close.addEventListener("click", leave_test);
}

// Validates itest form
function validate_itest_form(event)
{
    var form = event.target;
    event.preventDefault();
    renderItestDialog();  
}

// Leaves the test unfilled
function leave_test(event)
{
    event.preventDefault()
    window.location.replace("/test");
}

// Renders itest dialog
function renderItestDialog()
{
    var dialog = document.querySelector("#itest-dialog");
    dialog.addEventListener("close", force_submit_form);

    //var submit = document.querySelector("#dialog-submit");
    //submit.addEventListener("onclick", force_submit_form);

    //var reject = document.querySelector("#dialog-reject");
    //reject.addEventListener("onclick", dialog_reject);
    dialog.showModal();
}

// Submits form from the dialog
function force_submit_form(event)
{
    if(event.target.returnValue == "submit")
    {
        console.log("píča");
        var form = document.querySelector("#itest-form");
        var submitval = document.createElement("input");
        submitval.type = "hidden";
        submitval.name = "submit-test";
        submitval.value = "submit-test";
        form.appendChild(submitval);
        form.submit();
    }
}

// Checks if user filled all the question in the test FIXME: Remove this in the final version
function check_questions(form)
{
    for(q = 1; q <= form.dataset.questionCount; q++)
    {
        try
        {
            if(!checkAnswersChecked("question-" + q + "-answer-"))
            {
                return false;
            }
        }
        catch
        {
            var answer = document.querySelector("#question-" + q + "-answer-1");
            if(!answer.value)
            {
                return false;
            }
            return true;
        }
    }
    return true;
}