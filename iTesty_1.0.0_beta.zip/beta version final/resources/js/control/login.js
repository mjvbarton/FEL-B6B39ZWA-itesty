// Setting up Javascript environment and adding event listeners
function load() {
    var form = document.querySelector("#login-form");
    form.setAttribute("novalidate", "novalidate");
    var mail = document.querySelector("#usermail input");
    var pw = document.querySelector("#userpw input");

    form.addEventListener("submit", validateLogin);

    mail.addEventListener("blur", validateLoginField);
    mail.addEventListener("keyup", validateLoginField);

    pw.addEventListener("blur", validateLoginField);
    pw.addEventListener("keyup", validateLoginField);
}

// Validates login field
function validateLoginField(event) {
    target = event.target;
    error_message_box(target, "");

    if (target.value.length == 0) 
    {
        error_message_box(target, "Prosím, vyplňte toto pole");
        event.preventDefault();
    }
    else if(target.value.length < 5)
    {
        error_message_box(target, "Zadejte alespoň 5 znaků");
        event.preventDefault();
    }
    
    if(target.dataset.parentId == "usermail")
    {
        if(!((target.value.indexOf("@") > 0) && (target.value.indexOf(".") > 0)))
        {
            error_message_box(target, "Zadejte platnou emailovou adresu");
            event.preventDefault();
        }
    }

    if(target.dataset.parentId == "userpw")
    {
        var pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).*$/;
        if(!pattern.test(target.value))
        {
            error_message_box(target, "Zadané heslo musí obsahovat malá písmena, velká písmena a číslici");
            event.preventDefault();
        }
    }   
}

// Validates form after hitting the submit
function validateLogin(event) {
    var form = event.target;
    var blurEvent = new Event("blur");

    var mail = document.querySelector("#usermail input");
    var pw = document.querySelector("#userpw input");

    if((!mail.dispatchEvent(blurEvent)) || (!pw.dispatchEvent(blurEvent)))
    {
        event.preventDefault();
    }
}
//load();