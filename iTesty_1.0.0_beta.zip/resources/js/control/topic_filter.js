// Sets up javascript environment, assings event listenrs etc.
function load()
{
    var class_select = document.querySelector("#class-select");
    class_select.addEventListener("focus", uncheck_all_class);

    var all_class = document.querySelector("#toggle-all-class");
    all_class.addEventListener("change", empty_class_select);

    var topic_form = document.querySelector("#topic-select-form");
    topic_form.addEventListener("submit", validate_topic_form);
}

// Unchecks the default option toggle-all-class
function uncheck_all_class()
{
    var all_class = document.querySelector("#toggle-all-class");
    all_class.checked = false;
}

// Empties the class_select input after clicking on toggle-all-class
function empty_class_select(event)
{
    var class_select = document.querySelector("#class-select");
    var all_class = event.target;

    if(event.target.checked)
    {
        class_select.value = NaN;
    }
}

// Validates if one of topic checkboxes was checked
function validate_topic_form(event)
{
    var form = event.target;
    if(!checkAnswersChecked("topic-", form.dataset.maxElements))
    {
        event.preventDefault();
        var statusbox = create_status_box("Nevybrali jste žádné téma", STATUSBOX_TYPE_WARNING);
        searchbar = document.querySelector("#itest-topic div");
        if(searchbar.id !== "app-status-box")
        {
            searchbar.parentNode.insertBefore(statusbox, searchbar);
        }
    }

}