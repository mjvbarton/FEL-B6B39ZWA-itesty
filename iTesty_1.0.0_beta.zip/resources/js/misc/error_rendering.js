// Status box classes -> the same as in /assets/lib/_status-box.php
const STATUSBOX_TYPE_DEFAULT = "";
const STATUSBOX_TYPE_SUCCESS = "success";
const STATUSBOX_TYPE_WARNING = "warning";
const STATUSBOX_TYPE_WRONG = "wrong";

// Status box captions -> the same as in /assets/lib/_status-box.php
const STATUSBOX_CAPTION_DEFAULT = "Informace:";
const STATUSBOX_CAPTION_SUCCESS = "Úspěch";
const STATUSBOX_CAPTION_WARNING = "Upozornění";
const STATUSBOX_CAPTION_WRONG = "Chyba:";

// Shows error message box at the formfield
function error_message_box(node, msg, forceAdd = false)
{
    if((!node.nextElementSibling) || (forceAdd))
    {
        var parent = node.parentNode
        var error = document.createElement("span");
        error.classList = "formfield message-box hide-me";
        error.innerText = msg;
        parent.insertBefore(error, node.nextElementSibling);
    }

    var error = node.nextElementSibling;
    error.classList.remove("message-info");
    if(msg)
    {
        error.classList.remove("hide-me");
        error.innerText = msg;
    }
    else
    {
        error.classList.add("hide-me");
        error.innerText = "";
    }
    
}

// Shows info message box at the formfield
function info_message_box(node, msg, forceAdd = false)
{
    if(msg)
    {
        error_message_box(node, msg, forceAdd)
        var message_box = node.nextElementSibling;
        console.log(node.nextElementSibling);
        message_box.classList.add("message-info");
        //message_box.addEventListener("mouseleave", hide_message_box);
    }
    else
    {
        var message_box = node.nextElementSibling;
        message_box.classList.remove("message-info");
        error_message_box(node, msg, forceAdd)
    }
    
}

// Hides info message box
function hide_message_box(event)
{
    info_message_box(event.target, "");
}

// Creates statusbox element
function create_status_box(msg, type = STATUSBOX_TYPE_DEFAULT)
{
    var statusbox = document.createElement("div");
    statusbox.classList.add("status-box");
    statusbox.classList.add(type);
    statusbox.setAttribute("id", "app-status-box");
    switch(type)
    {
        case STATUSBOX_TYPE_SUCCESS:
        var caption = STATUSBOX_CAPTION_SUCCESS;
        break;

        case STATUSBOX_TYPE_WARNING:
        var caption = STATUSBOX_CAPTION_WARNING;
        break;

        case STATUSBOX_TYPE_WRONG:
        var caption = STATUSBOX_CAPTION_WRONG;
        break;

        default:
        var caption = STATUSBOX_CAPTION_DEFAULT;
        break;
    }
    statusbox.innerHTML = "<strong>" + caption + "</strong> " + msg;
    return statusbox;
}


