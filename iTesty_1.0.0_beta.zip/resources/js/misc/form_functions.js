// Functions which can be used globally
function hideElement(...elements)
{
    elements.forEach(element => 
        {
            element.classList.remove('hide-me');
            element.classList.add('hide-me');
        }
    );
}

function showElement(...elements)
{
    elements.forEach(element => 
        {
            element.classList.remove('hide-me');
        }
    );
}

// Displays error at form element
function displayError(element, message=null, displayElementState=true)
{
    element.classList.remove("wrong");
    var container = element.parentElement;

    if(message)
    {
        var errorMsg = document.createElement("span");
        errorMsg.classList = ["formfield wrong"];
        errorMsg.innerHTML = message;
        container.appendChild()
    }
    
    if(displayElementState)
    {
        element.classList.add("wrong")
    }
}

// Checks if radios 
function checkIfRadiosChecked(radios)
{
    radios.forEach(radio =>
        {
            if(radio.checked){
                return true;
            }
        });
    return false;
}

// Check if any answer is checked
function checkAnswersChecked(id_base, maxI = 5)
{
    for(i = 1; i <= maxI; i++)
    {
        var answer_radio = document.querySelector("#" + id_base + i);
        if((answer_radio) && (answer_radio.checked))
        {
            return true;
        }
    }
    return false;
}

// Query selector of multiple elements from radiobox (returns array)
function getElementsFromRadioBox(container, selector)
{
    
    console.log(radiobox);
    row = container.children
}
