## Obsah nápovědy

1. [Základní informace][1]
2. [Přihlášení a správa uživatele][2]
3. [Vytvoření nového testu][3]
4. [Vyplnění testu][4]
5. [Zobrazení napsaných testů][5]
5. [Vytváření otázek][6]
6. [Zásady tvorby otázek][7]
7. [Řešení problémů][8]
8. [O aplikaci][9]


[//]: # (Link connections:)
[1]: /help/01
[2]: /help/02
[3]: /help/03
[4]: /help/04
[5]: /help/05
[6]: /help/06
[7]: /help/07
[8]: /help/08
[9]: /help/09

