-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2019 at 02:08 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itesty_raw`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `gid` int(11) NOT NULL,
  `group_name` varchar(25) COLLATE utf8mb4_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci COMMENT='This functionality will be realized in next versions';

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`gid`, `group_name`) VALUES
(0, 'void');

-- --------------------------------------------------------

--
-- Table structure for table `institutions`
--

CREATE TABLE `institutions` (
  `iid` int(11) NOT NULL,
  `Name` varchar(50) COLLATE utf8mb4_czech_ci NOT NULL,
  `Address` varchar(150) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enabled` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

--
-- Dumping data for table `institutions`
--

INSERT INTO `institutions` (`iid`, `Name`, `Address`, `time_created`, `enabled`) VALUES
(0, 'Fictive institution', NULL, '2019-01-14 00:57:14', 1);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `qid` int(11) NOT NULL,
  `toid` int(11) NOT NULL,
  `creator_uid` int(11) NOT NULL,
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `heading` varchar(150) COLLATE utf8mb4_czech_ci NOT NULL,
  `description` varchar(150) COLLATE utf8mb4_czech_ci NOT NULL,
  `answer_type` varchar(10) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `answer_right` int(11) NOT NULL,
  `answer_count` int(11) NOT NULL DEFAULT '1',
  `answer1` varchar(25) COLLATE utf8mb4_czech_ci NOT NULL,
  `answer2` varchar(25) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `answer3` varchar(25) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `answer4` varchar(25) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `answer5` varchar(25) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `public` tinyint(1) NOT NULL DEFAULT '0',
  `valid` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `sid` int(11) NOT NULL,
  `iid` int(11) NOT NULL,
  `name` varchar(25) COLLATE utf8mb4_czech_ci NOT NULL,
  `description` varchar(150) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `teid` int(11) NOT NULL,
  `toid` int(11) NOT NULL,
  `creator_uid` int(11) NOT NULL,
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `te_name` varchar(20) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `evaluated` tinyint(1) NOT NULL DEFAULT '0',
  `evaluation_result` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test_content`
--

CREATE TABLE `test_content` (
  `id` int(11) NOT NULL,
  `teid` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `uaid` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `toid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_czech_ci NOT NULL,
  `description` varchar(80) COLLATE utf8mb4_czech_ci NOT NULL,
  `class` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL COMMENT 'unique ID of each user',
  `usermail` varchar(50) COLLATE utf8mb4_czech_ci NOT NULL,
  `userpw` varchar(255) COLLATE utf8mb4_czech_ci NOT NULL,
  `First_name` varchar(50) COLLATE utf8mb4_czech_ci NOT NULL,
  `Family_name` varchar(50) COLLATE utf8mb4_czech_ci NOT NULL,
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_edited` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `gid` int(11) NOT NULL DEFAULT '1' COMMENT 'user group id',
  `iid` int(11) NOT NULL DEFAULT '0',
  `ban` tinyint(1) NOT NULL DEFAULT '0',
  `sso_token` varchar(50) COLLATE utf8mb4_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `usermail`, `userpw`, `First_name`, `Family_name`, `time_created`, `time_edited`, `gid`, `iid`, `ban`, `sso_token`) VALUES
(0, 'admin@itesty.mjvbarton.cz', '$2y$10$osoZsby8BlKuGHqrrtHcjuKzcYlAeOOZcngISfvX26JbKhkcqV1XC', 'Správce', 'systému', '2019-01-14 01:05:20', '2019-01-14 01:05:42', 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_answers`
--

CREATE TABLE `user_answers` (
  `uaid` int(11) NOT NULL,
  `value` varchar(20) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

--
-- Dumping data for table `user_answers`
--

INSERT INTO `user_answers` (`uaid`, `value`, `time_created`) VALUES
(0, NULL, '2019-01-14 01:01:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`gid`),
  ADD UNIQUE KEY `group_name` (`group_name`);

--
-- Indexes for table `institutions`
--
ALTER TABLE `institutions`
  ADD PRIMARY KEY (`iid`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`qid`),
  ADD KEY `toid` (`toid`) USING BTREE,
  ADD KEY `creator_uid` (`creator_uid`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `InstitutionID` (`iid`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`teid`),
  ADD KEY `toid` (`toid`),
  ADD KEY `creator_uid` (`creator_uid`) USING BTREE;

--
-- Indexes for table `test_content`
--
ALTER TABLE `test_content`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `qid` (`qid`),
  ADD KEY `uaid` (`uaid`),
  ADD KEY `teid` (`teid`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`toid`),
  ADD KEY `sid` (`sid`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `unique_index` (`usermail`) USING BTREE,
  ADD KEY `InstitutionID` (`iid`),
  ADD KEY `gid` (`gid`);

--
-- Indexes for table `user_answers`
--
ALTER TABLE `user_answers`
  ADD PRIMARY KEY (`uaid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `institutions`
--
ALTER TABLE `institutions`
  MODIFY `iid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `qid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `teid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `test_content`
--
ALTER TABLE `test_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `toid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'unique ID of each user', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_answers`
--
ALTER TABLE `user_answers`
  MODIFY `uaid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`toid`) REFERENCES `topics` (`toid`),
  ADD CONSTRAINT `questions_ibfk_2` FOREIGN KEY (`creator_uid`) REFERENCES `users` (`uid`);

--
-- Constraints for table `tests`
--
ALTER TABLE `tests`
  ADD CONSTRAINT `tests_ibfk_2` FOREIGN KEY (`toid`) REFERENCES `topics` (`toid`),
  ADD CONSTRAINT `tests_ibfk_3` FOREIGN KEY (`creator_uid`) REFERENCES `users` (`uid`);

--
-- Constraints for table `test_content`
--
ALTER TABLE `test_content`
  ADD CONSTRAINT `test_content_ibfk_1` FOREIGN KEY (`teid`) REFERENCES `tests` (`teid`),
  ADD CONSTRAINT `test_content_ibfk_2` FOREIGN KEY (`qid`) REFERENCES `questions` (`qid`),
  ADD CONSTRAINT `test_content_ibfk_3` FOREIGN KEY (`uaid`) REFERENCES `user_answers` (`uaid`);

--
-- Constraints for table `topics`
--
ALTER TABLE `topics`
  ADD CONSTRAINT `topics_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `subjects` (`sid`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`gid`) REFERENCES `groups` (`gid`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`iid`) REFERENCES `institutions` (`iid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
