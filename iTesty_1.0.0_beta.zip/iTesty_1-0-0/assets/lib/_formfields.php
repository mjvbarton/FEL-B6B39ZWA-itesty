<?php

// Module for storing data about formfields and for validating forms (except itest)

// Default methods
const FORMFIELD_METHOD_GET = "get";
const FORMFIELD_METHOD_POST = "post";
const FORMFIELD_METHOD_FORCE_SET = "force";

// Max capacity of formfields group
const FORMFIELDS_FIELDGROUP_MAX_CAPACITY = 10000;

// Error messages
const FORMFIELD_ERR_LENGTH = "Zadejte řetězec správné délky. ";
const FORMFIELD_ERR_FILLED = "Prosím, vyplňte toto pole";
const FORMFIELD_ERR_CHECKED = "Prosím, zaškrtněte toto pole";
const FORMFIELD_ERR_CHECKED_MULTI = "Prosím, zaškrtněte toto pole";
const FORMFIELD_ERR_SELECTED = "Prosím, vyberte z tohoto seznamu";



// Class for formfield validation
class Formfield
{
    public function __construct(string $fieldname, int $max_length, string $method=FORMFIELD_METHOD_GET, bool $required=false, 
        bool $checkable = false, bool $selectable = false, string $force_set_value = null, bool $isMultiple = false)
    {
        $this->name = $fieldname; // Fieldname
        $this->max_len = $max_length; // Maximal length of field
        $this->isRequired = $required; // If field is required
        $this->isCheckable = $checkable; // If field is checkable
        $this->isMultiple = $isMultiple; // If field can be multiply checked
        $this->isSelectable = $selectable; // If field is selectable

        $this->isValid = true; // Parameter for common validation
        $this->error_msg = null; // Error message

        // Get value
        switch($method)
        {
            case FORMFIELD_METHOD_GET:
            $this->value = $_GET[$this->name];
            break;

            case FORMFIELD_METHOD_POST:
            $this->value = $_POST[$this->name];
            break;

            case FORMFIELD_METHOD_FORCE_SET:
            $this->value = $force_set_value; // TODO: Think about checking if value is entered
            break;

            default:
            die("Entered wrong method!");
            break;
        }

        // Set null value if empty string entered
        if($this->value == "")
        {
            $this->value = null;
        }
    }

    // Validates if formfield has right length
    private function validate_length()
    {
        if(!$this->max_len)
        {
            return true;
        }

        if(strlen($this->value) <= $this->max_len)
        {
            return true;
        }
        $this->value = null;
        $this->error_msg = FORMFIELD_ERR_LENGTH;
        return false;
        
    }

    // Validates if formfield was filled
    private function validate_fill()
    {
        if(is_array($this->value))
        {
            return true;
        }

        if(strlen($this->value) > 0)
        {
            return true;
        }
        else
        {
            if($this->isRequired)
            {
                $this->error_msg = FORMFIELD_ERR_FILLED;

                return false;
            }
            $_POST[$this->name] = null;
            return true;
        }
    }

    // Validate if formfield was checked
    private function validate_checked()
    {
        if($this->isMultiple)
        {
            return $this->validate_multiple_checked();
        }

        if($this->value == "-1")
        {
            if(($this->isCheckable) && ($this->isRequired))
            {
                $this->error_msg = FORMFIELD_ERR_CHECKED;
                return false;
            }
            
            return true;
        }
        return true;
    }

    // Validate if formfield was checked multiply
    private function validate_multiple_checked() : bool
    {
        if(is_array($this->value))
        {
            if(count($this->value) < 2)
            {
                $this->error_msg = FORMFIELD_ERR_CHECKED_MULTI;
                return false;
            }
            return true;
        }
        return true;
    }

    // Validate if formfield was selected
    private function validate_selected()
    {
        if($this->value == "-1")
        {
            if(($this->isSelectable) && ($this->isRequired))
            {
                $this->error_msg = FORMFIELD_ERR_SELECTED;
                return false;
            }
            
            return true;
        }
        return true;
    }

    // Validates htmlpatterm
    public function validate_pattern(string $pattern) : bool
    {
        if(!preg_match($pattern, $this->value))
        {
            //$this->valid = false;
            return false;
        }
        return true;
    }

    // Does the validation for outside method calling
    public function validate() : bool
    {
        if(($this->validate_length()) && ($this->validate_fill()) && ($this->validate_checked()) && ($this->isValid))
        {
            return true;
        }
        return false;
    }

    // Gets value of formfields (with htmlspecialchars escaped if html escape = true)
    public function get_value(bool $html_escape = true, $preserve_format=false)
    {
        if($html_escape)
        {
            return htmlspecialchars($this->value, ENT_QUOTES);
        }
        $toReturn = !$preserve_format ? (string) $this->value : $this->value;
        return $toReturn;
    }

    // Returns error message as string or null if no message
    public function get_error()
    {
        return $this->error_msg;
    }

    // Sets custom error message for outer validation
    public function custom_error_msg(string $message)
    {
        $this->isValid = false;
        $this->error_msg = $message;
    }

    public function set_required(bool $isRequired)
    {
        $this->isRequired = $isRequired;
    }
}


// Contatins formfields and also methods for working with them
class FormFieldContainer
{
    public function __construct()
    {
        $this->formfields = array(); // Associative array for storing formfield objects
    }

    // Checks if field is in field list
    private function find_field(string $name) : bool
    {
        foreach($this->formfields as $key => $value)
        {
            if($name == $key)
            {
                return true;
            }
        }
        return false;
    }

    // Returns object from field list
    public function field(string $name)
    {
        if($this->find_field($name))
        {
            return $this->formfields[$name];
        }
    }

    // Adds object of formfield to field list
    public function add_field(object $formfield)
    {
        $this->formfields[$formfield->name] = $formfield;
    }

    // Clears field list
    public function clear()
    {
        $this->formfields = null;
    }

    // Inserts objects from array with objects of class Formfield
    public function init_from_array(array $formfields, bool $clear = false)
    {
        if($clear)
        {
            $this->clear();
        }
        foreach($formfields as $formfield)
        {
            $this->add_field($formfield);
        }
    }

    // Add from field group (array of values)
    public function add_from_fieldgroup(string $group_name, string $element_name, array $params, bool $relation = false)
    {
        foreach($params as $key => $param)
        {   
            if(isset($param))
            {
                switch($key)
                {
                    case "max_length":
                    $max_len = (int) $param;
                    break;

                    case "required":
                    $required = (bool) $param;
                    break;

                    case "checkable":
                    $checkable = (bool) $param;
                    break;

                    case "selectable":
                    $selectable = (bool) $param;
                    break;
                }
            }          
        }
        if($relation)
        {
            $required = false;
        }

        $i = 1;
        $lastkey = "$element_name$i";
        $last = true;
        foreach($_POST[$group_name] as $groupfield)
        {
            $key = "$element_name$i";
            $this->add_field(new FormField($key, $max_len, FORMFIELD_METHOD_FORCE_SET, $required, $checkable, $selectable, $groupfield));
            
            // Validating if filled in relation
            if($relation)
            {
                if(!$this->field($key)->value)
                {
                    $actual = false;
                }
                else
                {
                    $actual = true;    
                }
                if($actual > $last || $i == 1)
                {
                    $this->field($lastkey)->set_required(true);
                }
                $last = $actual;
                $lastkey = $key;
            }
            $i++;
        }
    }

    // Gets data from fieldgroup
    public function get_data_from_field_group(string $element_name, bool $html_escape = true) : array
    {   
        $result = array();
        for($i = 1; $i <= FORMFIELDS_FIELDGROUP_MAX_CAPACITY; $i++)
        {   
            $key = "$element_name$i";
            if($this->field($key))
            {
                $result[$key] = $this->field($key)->get_value($html_escape);
            }
            else
            {
                break;
            }
        }
        
        return $result;
    }

    // Validates all fields in field list
    public function validate_fields() : bool
    {
        $result = true;
        foreach($this->formfields as $formfield)
        {
            if((!$formfield->validate()) && ($result))
            {
                $result = false;
            }
        }
        return $result;
    }
}