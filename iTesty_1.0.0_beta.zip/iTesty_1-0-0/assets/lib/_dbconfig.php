<?php
    // Before first start set right credentials for the database
    const SQL_HOST = "itesty.prgcons.cz";
    const SQL_USR = "itest_db";
    const SQL_PW = "tvojemama25";
    const SQL_DB = "itesty";

    // Global PDO object used by models
    global $db;
    $db = new PDO("mysql:host=".SQL_HOST.";dbname=".SQL_DB.";charset=utf8mb4", SQL_USR, SQL_PW);

?>