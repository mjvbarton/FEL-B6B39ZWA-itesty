<?php

// MODULE FOR HANDLING TEST TOPICS

// Checking the availability of the DB
$db = isset($GLOBALS["db"]) ? $GLOBALS["db"] : null;
if(!isset($db))
{
    die("No DB found");
}

// Class for handling topics
class iTestTopic
{
    public function __construct($toid)
    {
        $this->toid = $toid;

        // Setting up MYSQL connection
        $this->db = $GLOBALS["db"];
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT name, description, class, sid FROM topics WHERE toid=:toid AND enabled=1";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(":toid", $this->toid);
        
        // Do sth if query fails
        if(!$stmt->execute())
        {
            die("Error connecting");
        }
        
        // Loading data
        if($row = $stmt->fetch(PDO::FETCH_ASSOC))
        {
            $this->name = $row['name'];
            $this->sid = $row['sid'];
            $this->description = $row['description'];
            $this->class = $row['class'];
        }

        $this->count_questions = $this->get_qids();
    }

    public function get_qids() : int
    {
        $sql = "SELECT qid FROM questions WHERE toid = :toid ORDER BY qid";
        $stmt = $this->db->prepare($sql);
        if(!$stmt->execute([":toid" => $this->toid]))
        {
            die("Error connecting"); //TODO:
        }

        $count = 0;
        $qids = array();
        while($row = $stmt->fetch())
        {
            $qids[] = $row[0];
            $count++;
        }

        $this->qids = $qids;
        return $count;
    }
}

// Class for filtering topics
class iTestTopicFilter
{
    public const COUNT_TOPICS_PER_PAGE = 10; // Determines how many tests should be located on single page
    private const DEFAULT_PAGENUM = 1;
    private const SHOW_DISABLED_TOPICS = False;

    public function __construct(array $params = array())
    {
        $this->class = 0; // Key for evaluation filter | 0 all classes | 1 - n show topics for the n-th class
        $this->sid = 0; // Subject ID to filter by
        $this->toname = "";
        $this->page_num = $this::DEFAULT_PAGENUM; // Number of page selected

        $this->topics = array(); // Array for storing topic objects
        $this->data = array(); // Array for storing data for sql queries
        $this->pagination = [
            "left" => False,
            "right" => False
        ]; // Determines if the view should enable right pagination, left pagination or both of them
        $this->empty = False; // Determines if the test filter is empty
        $this->sql_condition = ""; // Placeif(!$stmt->execute($this->data))
        
        $this->db = $GLOBALS["db"]; // PDO Object with DB connection

        if($params)
        {
            $this->get_params($params);
        }
    }

    // This function returns parameters for the filter
    private function get_params(array $params)
    {
        foreach ($params as $key => $value)
        {
            switch($key)
            {
                case "class":
                $this->class = (int) $value;
                break;

                case "sid":
                $this->sid = (int) $value;
                break;

                case "toname":
                $this->toname = (string) $value;
                break;
            }
        }
    }

    // This function will load tests into the object. It will also run several subfunctions defined below.
    public function load_topics()
    {
        $this->load_data();
    }

    // Checks if current page number is the right one
    public function check_page_num() : bool
    {
        if(!isset($this->max_page))
        {
            $this->enable_pagination();
        }

        if($this->empty)
        {
            return True;
        }

        if((0 < $this->page_num) && ($this->page_num <= $this->max_page))
        {
            return True;
        }
        return False;
    }

    // Determining algorithm which of the pagination should we turn on.
    public function enable_pagination() : void
    {
        // Setting right limits for query       
        $offset = ($this->page_num - 1) * $this::COUNT_TOPICS_PER_PAGE;

        // Doing SQL query
        $sql = "SELECT COUNT(*) ".$this->get_sql_condition();

        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $this->db->prepare($sql);
        
        if(!$stmt->execute($this->data))
        {
            die("Error connecting");
        }

        // If there's no result mark the object as empty
        if((!$row = $stmt->fetch()))
        {
            $this->empty = True;
        }
        
        // If the rowset is empty
        if(!$count = (int) $row[0])
        {
            $this->empty = True;
        }
        
        // Turning on the right pagination
        if($count- $this::COUNT_TOPICS_PER_PAGE > $offset)
        {
            $this->pagination["right"] = True;
        }

        // Turning on the left pagination
        if($this->page_num > 1)
        {
            $this->pagination["left"] = True;
        }

        $max_page = (int) ($count / $this::COUNT_TOPICS_PER_PAGE);
        $this->max_page = ($max_page * $this::COUNT_TOPICS_PER_PAGE == $count) ?
            $max_page : $max_page + 1;
        
        return;
    }

    // This function will load data into variable $this->topics
    private function load_data() : bool
    {
        // Setting up limits for the query
        $limit = $this::COUNT_TOPICS_PER_PAGE;
        $offset = ($this->page_num - 1) * $this::COUNT_TOPICS_PER_PAGE;

        // Doing sql query
        $sql = "SELECT topics.toid ".$this->get_sql_condition()." LIMIT $limit OFFSET $offset";
        $stmt = $this->db->prepare($sql);
        
        // Die if the query fails
        if(!$stmt->execute($this->data))
        {
            die("Error connecting");
        }

        // Getting data from the query and loading them into $this->topics
        while($row = $stmt->fetch())
        {
            $this->topics[] = new iTestTopic($row[0]);
        }
        
        return !$this->topics ? False : True;
    }

    // Counts limits for sql query
    public function count_limit() : array
    {
        $max = $this::COUNT_TOPICS_PER_PAGE + (($this->page_num - 1) * $this::COUNT_TOPICS_PER_PAGE);
        $min = 1 + (($this->page_num - 1 ) * $this::COUNT_TOPICS_PER_PAGE);
        return [$min, $max];
    }

    // Builds up the sql condition
    private function get_sql_condition() : string
    {
        // Required parameter User ID
        $sql = "FROM topics WHERE topics.enabled = ".!$this::SHOW_DISABLED_TOPICS;

        // Filter by subject
        if($this->sid)
        {
            $sql .= " AND topics.sid = :sid";
            $this->data[":sid"] = $this->sid;
        }

        // Filter by evaluated
        if($this->class)
        {
            $sql .= " AND topics.class = :class";
            $this->data[":class"] = $this->class;
        }       

        // Filter by topic name
        if($this->toname)
        {    
            $sql .= " AND topics.name LIKE CONCAT(:toname, '%')";
            $this->data[":toname"] = $this->toname;
            
        }

        // Set ordering
        $sql .= " ORDER BY topics.name, topics.toid";
        return $sql;
    }
}