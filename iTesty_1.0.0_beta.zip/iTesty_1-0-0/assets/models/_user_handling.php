<?php
    const SESSION_TIMEOUT = 60 * 60;

    // Class for managing login
    class Login
    {
        public function __construct($username, $password, $sso = false)
        {
            $this->username = $username;
            $this->password = $password;
            $this->sso = $sso;

            $this->db = $GLOBALS["db"];
        }
        
        // Gets uid by the usermail
        private function get_uid()
        {
            
            $sql = "SELECT uid FROM users WHERE usermail = :usermail";
    
            $stmt = $this->db->prepare($sql);
            if(!$stmt->execute([":usermail" => $this->username]))
            {
                return false;
            };
    
            if($row = $stmt->fetch())
            {
                $this->uid = $row["uid"];
                return true;
            }
            else
            {
                return false;
            }
            
        }

        // Compares formfield password with the one in DB
        private function verify_password()
        {
            $sql = "SELECT userpw FROM users WHERE uid= :uid";
            $stmt = $this->db->prepare($sql);
            if(!$stmt->execute([":uid" => $this->uid]))
            {
                return false;
            };

            if($row = $stmt->fetch())
            {                
                return password_verify($this->password, $row["userpw"]);
            }
            return false;
        }

        // Saves uid to the session
        private function set_session()
        {
            $_SESSION["uid"] = $this->uid;
        }

        // Sets cookie time out for specified time
        private function set_timeout_cookie()
        {
            setcookie("session_timeout", $this->uid, time() + SESSION_TIMEOUT);
        }

        // Enables the SSO FIXME:
        public function enable_sso() : bool
        {
            $toHash = $this->username.$this->password.$this->uid.time();
            $sso_token = password_hash($toHash);

            $sql = "UPDATE users SET sso_token = :token WHERE uid = :uid";
            $stmt = $this->db->prepare($sql);
            if(!$stmt->execute([":token" => $sso_token, ":uid" => $this->uid]))
            {
                return false;
            }
            setcookie("sso_token", $sso_token);
            return true;
        }

        // Does sign in
        public function sign_in()
        {
            if($this->get_uid())
            {
                if($this->verify_password())
                {
                    $this->set_session();
                    // FIXME:
                    if($this->sso)
                    {
                        $this->enable_sso();
                    }
                    else
                    {
                        $this->set_timeout_cookie();
                    }
                    return true;
                }
                return false;
            }
            return false;
        }
    }

    class User
    {
        const GET_NAME_FULLNAME = 3;
        const GET_NAME_FIRST = 2;
        const GET_NAME_FAMILY = 1;

        public function __construct(int $uid)
        {
            $this->uid = $uid;
            $this->db = $GLOBALS["db"];

            $this->load_data();
        }

        private function load_data()
        {
            $sql = "SELECT usermail, first_name, family_name, time_created, time_edited, gid, iid, ban FROM users WHERE uid = :uid";
            $stmt = $this->db->prepare($sql);
            if(!$stmt->execute([":uid" => $this->uid]))
            {
                die("Error connecting"); //TODO:
            }
            if($row = $stmt->fetch(PDO::FETCH_ASSOC))
            {
                $this->username = $row["usermail"];
                $this->time_created = $row["time_created"];
                $this->name["first_name"] = $row["first_name"];
                $this->name["family_name"] = $row["family_name"];
                $this->gid = (int) $row["gid"];
                $this->iid = (int) $row["iid"];
                $this->ban = (bool) $row["ban"];
                return true;
            }
            die("No user found"); //TODO:
        }

        public function get_name(int $mode) :string
        {
            switch($mode)
            {
                case $this::GET_NAME_FAMILY:
                $toReturn = $this->name["family_name"];
                break;

                case $this::GET_NAME_FIRST:
                $toReturn = $this->name["first_name"];
                break;

                case $this::GET_NAME_FULLNAME:
                $toReturn = $this->name["first_name"]. " " . $this->name["family_name"];
                break;

                default:
                $toReturn = (string) null;
                break;
            }

            return $toReturn;
        }
    }

    
