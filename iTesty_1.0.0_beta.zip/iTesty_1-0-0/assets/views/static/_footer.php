<?php
    const APP_VERSION = "1.0.0 beta";
    const APP_AUTHOR = "Matěj Bartoň";
    const APP_SERVICE_CONTACT = "podpora.itesty@mjvbarton.cz";

    function get_copyright()
    {
        $year = date("Y");
        echo "iTesty ".APP_VERSION." - &copy; 2018-$year ".APP_AUTHOR;
    }
?>
<div class="footer-left">
    <?php get_copyright(); ?>
</div>
    
<div class="footer-right">
        <a href="mailto:<?php echo APP_SERVICE_CONTACT; ?>"><i class="fa fa-bug">&nbsp;</i>Nahlásit problém</a>
</div>