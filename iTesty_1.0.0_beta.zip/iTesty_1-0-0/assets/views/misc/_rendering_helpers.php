<?php
    // Gets error message from fieldlist of formfields
    function get_error(object $formfields, string $name)
    {
        if($formfields->field($name))
        {
            return $formfields->field($name)->get_error();
        }
        else
        {
            return null;
        }
    }

    // Shows error message in <span> at the formfield
    function showErrorMessage($msg)
    {
        if($msg)
        {
            return "<span class='formfield message-box'>$msg</span>";
        }
        return "";
    }

    // Formats itest time created
    function get_time_created(object $itest)
    {
        $time = strtotime($itest->time_created);
        echo date("j.m.Y G:i", $time);
    }

    // Formats itest evaluation result
    function get_itest_corrected(object $itest, $element = "span", $classList = "formfield")
    {
        if($itest->evaluated)
        {
            $evaluation_result = $itest->evaluation_result;
            if($evaluation_result == 0) 
            {
                $status = "wrong"; //CSS_QUESTION_WRONG
            }
            else
            {
                $status = "success"; //CSS_QUESTION_CORRECT
            }
            echo "<$element class='$classList $status'>$evaluation_result% správně</$element>";
        }
        else
        {
            echo "<$element class='$classList'><em>nehodnoceno</em></$element>";
        }
    }

    function get_itest_view_button(object $itest)
    {
        if($itest->evaluated)
        {
?>
        <a class="formfield btn btn-table" href="/test/show/<?php echo htmlspecialchars($itest->teid); ?>">
            <i class="fa fa-eye">&nbsp;</i>Zobrazit
        </a>
<?php
        return;    
        }
?>
        <a class="formfield btn btn-quit btn-table" href="/test/show/<?php echo htmlspecialchars($itest->teid); ?>">
            <i class="fa fa-edit">&nbsp;</i>Vyplnit
        </a>
<?php
    }