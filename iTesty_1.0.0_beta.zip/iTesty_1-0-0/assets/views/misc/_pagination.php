<?php

// View for rendering pagination mechanisms

// Pagination for Tests View --> TODO: Make single object for pagination in the next version
function renderTestPagination(object $filter, string $form = "")
{
    if($form)
    {
        $form = "form='$form' ";
    }
?>

<?php
    if($filter->pagination["left"])
    {
?>  
    <button name="page" <?php echo $form;?>value="<?php echo $filter->page_num - 1;?>" type="submit" class="formfield btn pg-left">
        <i class="fa fa-arrow-left">&nbsp;</i>
        <span class="hide-me">Předchozí</span>
    </button>
    
<?php
    }
    if(($filter->pagination["left"]) || ($filter->pagination["right"]))
    {
?>  
    <progress value="<?php echo htmlspecialchars($filter->page_num); ?>" max="<?php echo htmlspecialchars($filter->max_page); ?>" class="pg-number formfield progress">2/2</progress>
<?php
    }
    if($filter->pagination["right"])
    {
?>
    <button name="page" <?php echo $form;?>value="<?php echo $filter->page_num + 1;?>" type="submit" class="formfield btn pg-right">
        <i class="fa fa-arrow-right">&nbsp;</i>
        <span class="hide-me">Předchozí</span>
    </button>
<?php
    }
}