<span class="hide-me"></span>
<li><a href="/help" class="vis-guest"><i class="fa fa-question-circle">&nbsp;</i>Nápověda</a></li>