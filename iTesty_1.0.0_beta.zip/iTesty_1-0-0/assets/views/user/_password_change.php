<?php

// This is view which shows you written tests

    // Including necessary views with functions
    include("views/static/_header.php");
    include("views/misc/_pagination.php");
    include("views/misc/_rendering_helpers.php")
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    
    <title>iTesty - Můj profil</title>

    <link rel="stylesheet" href="/resources/css/main.css" media="all">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--<link rel="stylesheet" href="resources/css/print.css" media="print"> FIXME: -->
    
</head>

<body>

    <!-- Top menu bar -->

    <nav class="menu-top" id="topbar">
        <?php get_header("_topmenu-user") ?>;
    </nav>
    
    <!-- Header of current page -->

    <header>
        <h1>Homepage</h1>
        <hr class="hide-separator" />
    </header>

    <!-- Page -->

    <main id="page" class="no-sidebar">

        <!-- Password change form -->

        <section id="password-change">
            <h2>Změnit heslo</h2>
            <form action="/user/password_change" method="post">
                <div class="formfield">
                    <label class="formfield important-label">
                        Současné heslo:
                        <input class="login-text formfield text-input" type="password" name="oldpw" size="50" placeholder="*********" required="required" data-parent-id = "userpw"/>
                    </label>
                </div>
                <div class="formfield">
                    <label class="formfield important-label">
                        Nové heslo:
                        <input class="login-text formfield text-input" type="password" name="oldpw" size="50" placeholder="*********" required="required" data-parent-id = "userpw"/>
                    </label>
                </div>
                <div class="formfield">
                    <label class="formfield important-label">
                        Nové heslo znovu:
                        <input class="login-text formfield text-input" type="password" name="oldpw" size="50" placeholder="*********" required="required" data-parent-id = "userpw"/>
                    </label>
                </div>
                <button name="changePw" value="changePw" type="submit" class="formfield btn btn-submit">
                    <i class="fa fa-check">&nbsp;</i>
                    Potvrdit
                </button>

                <button name="reject" value="reject" type="submit" class="formfield btn btn-quit">
                    <i class="fa fa-close">&nbsp;</i>
                    Zrušit
                </button>
            </form>
        </section>
    </main>

    <!-- Footer -->

    <footer id="bottombar">
        <?php include("views/static/_footer.php"); ?>
    </footer>
    <script>load();</script>
</body>
</html>