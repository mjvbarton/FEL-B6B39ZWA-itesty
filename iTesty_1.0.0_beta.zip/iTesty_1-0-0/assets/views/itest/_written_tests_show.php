<?php

// This is view which shows you written tests

    // Including necessary views with functions
    include("views/static/_header.php");
    include("views/misc/_pagination.php");
    include("views/misc/_rendering_helpers.php")
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    
    <title>iTesty - Napsané testy</title>

    <link rel="stylesheet" href="/resources/css/main.css" media="all">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--<link rel="stylesheet" href="resources/css/print.css" media="print"> FIXME: -->
    <script src="/resources/js/control/test_filter.js"></script>
    <script src="/resources/js/ajax/topic_filter.js"></script>
</head>

<body>

    <!-- Top menu bar -->

    <nav class="menu-top" id="topbar">
        <?php get_header("_topmenu-user") ?>;
    </nav>
    
    <!-- Header of current page -->

    <header>
        <h1>Homepage</h1>
        <hr class="hide-separator" />
    </header>

    <!-- Page -->

    <main id="page" class="no-sidebar">

        <!-- Section with written tests -->

        <section id="written-tests">
            <h2>Napsané testy</h2>
            <div class="itest topic topic-select test-view">

                <!-- Test search bar -->

                <div class="itest topic topic-search">
                    <form action="/user/tests" method="get">
                    <div class="formfield">
                        <label>
                            Vyhledat téma:
                            <input id="search_topic" class="formfield text-input" type="text" name="toname" list="toidselect_data"
                            value="<?php echo isset($_GET["toname"]) ? htmlspecialchars($_GET["toname"]) : ""; ?>" autocomplete="off"/>
                            <datalist id="toidselect_data">
                                
                            </datalist>
                        </label>
                        <button class="formfield btn" type="submit" value="search_topic">
                            <i class="fa fa-search"></i><span class="hide-me">Vyhledat</span>
                        </button>
                    </div>
                    <div class="formfield">
                        <label>
                            Předmět:
                            <input type="hidden" value="0" />
                            <select id="search_class" class="formfield select" name="sid" value="0">
                                <option value="0">všechny</option>
                            <?php
                                foreach($subjects->subjects as $subject)
                                {
                                    $selected = isset($_GET["sid"]) && $_GET["sid"] == $subject->sid ? "selected" : "";
                                    echo "<option value='{$subject->sid}' $selected>".htmlspecialchars($subject->name)."</option>";
                                }
                            ?>
                            </select>
                        </label>
                    </div>
                    <div class="formfield">
                        <label>
                            Stav testu:
                            <input type="hidden" value="0" />
                            <select id="search_class" class="formfield select" name="evaluated" value="0">
                                <option value="0">všechny</option>
                                <option value="2" <?php echo isset($_GET["evaluated"]) && $_GET["evaluated"] == 2 ? "selected" : ""; ?>>
                                    vyplněno
                                </option>
                                <option value="1" <?php echo isset($_GET["evaluated"]) && $_GET["evaluated"] == 1 ? "selected" : ""; ?>>
                                    nevyplněno
                                </option>
                            </select>
                        </label>
                    </div>
                    <div class="formfield">
                        <button class="formfield btn" type="submit" name="filter" value="filter">
                            <i class="fa fa-filter"></i><span class="hide-me">Filtr</span>
                        </button>
                    </div>
                </div>

                <!-- Table with tests -->

                <table class="itest-table structure">
                    <thead>
                        <tr>
                            <td class="test-view itest-table cell cell-text">Téma testu:</td>
                            <td class="test-view itest-table cell cell-text">Předmět:</td>
                            <td class="test-view itest-table cell cell-numeric">Hodnocení:</td>
                            <td class="test-view itest-table cell cell-numeric">Vytvořeno:</td>
                            <td></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            
                            foreach($testFilter->tests as $itest)
                            {
                        ?>
                        <tr>
                            <td class="test-view itest-table cell cell-text"><?php echo htmlspecialchars($itest->topic->name); ?></td>
                            <td class="test-view itest-table cell cell-text"><?php echo htmlspecialchars($itest->subject->name); ?></td>
                            <?php get_itest_corrected($itest, "td", "test-view itest-table cell cell-numeric"); ?>
                            <td class="test-view itest-table cell cell-numeric"><?php get_time_created($itest); ?></td>
                            <td>
                                <?php get_itest_view_button($itest); ?>
                            </td>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                </table>

                <!-- Pagination -->

                <div id="table-pagination">
                    <?php renderTestPagination($testFilter); ?>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->

    <footer id="bottombar">
        <?php include("views/static/_footer.php"); ?>
    </footer>
    <script>load();</script>
</body>
</html>