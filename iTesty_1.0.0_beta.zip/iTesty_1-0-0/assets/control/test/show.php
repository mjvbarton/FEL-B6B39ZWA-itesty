<?php
    
    include("models/_test_handling.php");

    $teid = isset($todo[3]) && ((int) $todo[3]) ? (int) $todo[3] : null;

    // Get test id parametr from the URI
    if(($teid) && ($itest = new iTest((int) $teid)))
    {
        // Checking if itest was evaluated
        if($itest->evaluated)
        {
            $itest->evaluate($itest->content->load_answers());
            include_once("views/itest/_question_formshow.php"); // Including the proper view
            exit();
        }
        header("Location: /test/fill/$teid"); // Redirect to test fill form
    }
    else
    {
        header("Location: /test"); // Redirect to test generator
    }