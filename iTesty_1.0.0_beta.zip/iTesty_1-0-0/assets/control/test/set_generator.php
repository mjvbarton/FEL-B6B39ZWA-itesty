<?php
    include_once("models/_subject_handling.php");
    include_once("models/_topic_handling.php");
    const SETGEN_MODE_START = 1;
    const SETGEN_MODE_PARAMS = 2;

    // Loading available subjects
    $subjects = new iTestSubjectContainer();

    // Setting up subject id according to the URI
    $sid = isset($todo[3]) && is_int((int) $todo[3]) ? (int) $todo[3] : 1;
    
    // Handling filter/search form
    if(isset($_GET["allclass"]))
    {
        $_GET["class"] = trim($_GET["allclass"]);
    }
    $filter_params = readGetParams();
    $filter_params["sid"] = $sid;

    $topicFilter = new iTestTopicFilter($filter_params);
    $topicFilter->enable_pagination();
    $topicFilter->load_topics();

    // Selecting subjects and preparing formfield container
    $subject = $subjects->subject($sid);
    $formfields = new FormFieldContainer();
    
    // Topic select form validation
    if(isset($_POST["toid"]))
    {
        $formfields->add_field(new Formfield("toid", 0, FORMFIELD_METHOD_POST, false, false, false, null, true));
        if($formfields->validate_fields())
        {
            $setgen_mode = SETGEN_MODE_PARAMS;
        }
    }

    // Setting generator mode
    $setgen_mode = isset($setgen_mode) ? $setgen_mode : SETGEN_MODE_START;
    include("views/itest/_generator_formshow.php");