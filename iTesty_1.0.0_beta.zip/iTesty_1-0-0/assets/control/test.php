<?php
    function action_default(array $todo)
    {
        header("Location: /test/generator");
    }

    function generator(array $todo)
    {
        if(!isset($todo[3]) || (!$todo[3]))
        {
            header("Location: /test/generator/1");
        }

        include_once("models/_subject_handling.php");
        $subjects = new iTestSubjectContainer();
        if((!$subjects->subject((int) $todo[3])))
        {
            header("Location: /test/generator/1");
        }

        if(isset($_POST["generate"]))
        {
            include("control/test/generator.php");
            return;
        }   

        include("control/test/set_generator.php");
    }

    function fill(array $todo)
    {
        $action = get_action_path($todo);
        if(file_exists($action))
        {
            include($action);
        }
    }

    function show(array $todo)
    {
        $action = get_action_path($todo);
        if(file_exists($action))
        {
            include($action);
        }
    }