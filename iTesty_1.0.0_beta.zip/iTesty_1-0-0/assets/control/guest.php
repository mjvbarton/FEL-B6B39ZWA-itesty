<?php
// GUEST - action controller for handling guest website

// This is the default action of the action controller
function action_default(array $todo)
{
    $formfields = new FormFieldContainer();

    // This private function validates if usermail is valid email address
    function validateEmail($formfields) : bool
    {   
        if(($value = $formfields->field("usermail")->get_value(false)) && (!(strpos($value, "@") !== false)) && (!(strpos($value, ".") !== false)))
        {
            $formfields->field("usermail")->custom_error_msg("Prosím, zadejte platný email");
            return false;
        }
        return true;
    };

    // Validates password according to the pattern
    function validatePassword($formfields) : bool
    {   
        if(!$formfields->field("userpw")->validate_pattern("^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).*$^"))
        {
            $formfields->field("userpw")->custom_error_msg("Zadané heslo musí obsahovat malá písmena, velká písmena a číslici");
            return false;
        }
        return true;
    };


    // Login form validation
    if(isset($_POST["submit_login"]))
    {
        $formfields->add_field(new Formfield("usermail", 50, FORMFIELD_METHOD_POST, true));
        $formfields->add_field(new Formfield("userpw", 50, FORMFIELD_METHOD_POST, true));
        
        // Special validation of login formfields
        validateEmail($formfields);
        validatePassword($formfields);

        // Validation with Formfield library
        if($formfields->validate_fields())
        {
            $usermail = $formfields->field("usermail")->get_value();
            $userpw = $formfields->field("userpw")->get_value();
            include_once("models/_user_handling.php");

            // Performing login
            $login = new Login($usermail, $userpw);
            if($login->sign_in())
            {
                header("Location: /");
            }
            else
            {
                $err_login = "Špatné uživatelské jméno nebo heslo";
                $formfields->field("usermail")->custom_error_msg($err_login);
                $formfields->field("userpw")->custom_error_msg($err_login);
            }
            
        }
    }
    include("views/_homepage.php");
}