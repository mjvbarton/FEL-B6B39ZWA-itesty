<?php
    include_once("models/_subject_handling.php");
    include_once("models/_topic_handling.php");

    $subjects = new iTestSubjectContainer();

    // Validation of the subject
    if(isset($_GET["sidselect"]))
    {
        $subject = $subjects->subject($_GET["sidselect"]);
        if($subject)
        {
            $_GET["sid"] = trim($subject->sid);
            $validSubject = True;
        }
        else
        {
            $validSubject = False;
        }
    }
    else
    {
        $validSubject = False;
    }
    // $_GET parameters validation
    $filter_params = readGetParams();

    // Get data
    $topicFilter = new iTestTopicFilter($filter_params);
    $topicFilter->enable_pagination();
    $topicFilter->load_topics();

    // Parse topic names data to array
    $returnTopics = array();
    foreach($topicFilter->topics as $topic)
    {
        $returnTopics[] = htmlspecialchars($topic->name);
    }

    $result = [      
                "topics" => $returnTopics,
                "validSubject" => $validSubject,
                "empty" => $topicFilter->empty
            ];
    
    echo json_encode($result);




