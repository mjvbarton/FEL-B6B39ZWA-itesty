<?php

//FRONT CONTROLLER

// Configuration TODO: Move all configuration to an includable file
const PARAMS = "params";
const STORAGE = "assets";
const ACTION_CONTROLLERS = "control";
const FILE_SEPARATOR = "/";
const MODELS = "models";
const VIEWS = "views";
const MDFILES_STORAGE = "/resources/md/";

const ACCESS_GUEST = "guest";
const ACCESS_USER_COMMON = "user";

const CLASS_MIN = "1";
const CLASS_MAX = "6";

const RESTRICTED_USER_COMMON_LOOKUP = "user|test|question";
const PUBLIC_PAGES_LOOKUP = "guest|help";

const ITEST_MAX_ANSWERS_COUNT = 50;
const ITEST_MAX_QUESTIONS_ALLOWED = 50;
const ITEST_MIN_QUESTIONS_ALLOWED = 5;

const ITEST_NAME_DEFAULT = "ITEST_";

// Redirects
const REDIR_TESTGEN_START = "/test";
const REDIR_TEST_SHOW = "/test/show";

// Evaluation messages
const EVAL_MSG_CORRECT = "success";
const EVAL_MSG_WRONG = "wrong";

// TODO: Consider moving this function to an another file
function isPublicPage(string $controller, string $lookup = PUBLIC_PAGES_LOOKUP, string $separator = "|") : bool
{
    $lookup = explode("|", $lookup);
    foreach($lookup as $element)
    {
        if($controller == $element)
        {
            return true;
        }
    }
    return false;
}

// Returns path for action (must be call in the action controller)
function get_action_path(array $todo) : string
{
    $path = $_SERVER["DOCUMENT_ROOT"].FILE_SEPARATOR
            .STORAGE.FILE_SEPARATOR
            .ACTION_CONTROLLERS.FILE_SEPARATOR
            .$todo[0].FILE_SEPARATOR
            .$todo[1].".php";
    return $path;
}
// Setting include path
set_include_path(get_include_path(). PATH_SEPARATOR. $_SERVER['DOCUMENT_ROOT']."/".STORAGE);

// Include libraries for work
include("lib/_formfields.php");
include("lib/_formfields_validation_helpers.php");
include("lib/_mdfiles.php");
include("lib/_status-box.php");
include("lib/_app_state.php");
include("lib/_dbconfig.php");
include("lib/_urilib.php");
session_start();

$todo = parseUri(isset($_GET[PARAMS]) ? $_GET[PARAMS] : "", 
isset($_SESSION["uid"]) ? ACCESS_USER_COMMON : ACCESS_GUEST);

if((!isset($_SESSION["uid"])) && (!isPublicPage($todo[0])))
{
    header("Location: /");
    exit();
}

// Selecting action controller
$action_controller = ACTION_CONTROLLERS."/".$todo[0].".php";

if(file_exists(STORAGE."/".$action_controller))
{
    include($action_controller);

}
else
{
    echo "Error 404 - Not Found"; //TODO:
    exit();
}

// Selecting action
if(function_exists($todo[1]))
{
    $todo[1]($todo);
}
elseif($todo[0] == "help")
{
    get_help_content($todo[1]);
}
else
{
    echo "Error 404 - Not Method Found"; //TODO:
    exit();
}


// Closing DB connection
if(isset($db))
{
    unset($db);
}
