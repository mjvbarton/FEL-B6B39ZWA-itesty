<?php /*
    foreach($_SERVER as $key => $row)
    {
        printf("$key => $row.<br>");
    }

    $ACTION = $_SERVER["REQUEST_URI"];
    $uri = explode("?", $ACTION);
    echo $uri[1];
    
    $str = "ITEST_1";
    var_dump(is_bool(strpos($str, "ITEST_")));
*/
// Setting include path
set_include_path(get_include_path(). PATH_SEPARATOR. $_SERVER['DOCUMENT_ROOT']."/assets");

// Include libraries for work
include("lib/_formfields.php");
include("lib/_formfields_validation_helpers.php");
include("lib/_mdfiles.php");
include("lib/_status-box.php");
include("lib/_app_state.php");
include("lib/_dbconfig.php");
include("lib/_urilib.php");
session_start();
echo password_hash("admin", PASSWORD_DEFAULT);
    
    