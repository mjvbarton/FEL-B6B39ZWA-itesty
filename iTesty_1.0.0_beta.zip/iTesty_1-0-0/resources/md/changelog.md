[//]: # (Changelog file)
[//]: # (Use <h3> for headings)
### Verze 0.80.0 alpha
* přidány filtry témat a testů
* přidán Javascript
* odstraněny bugy z testové části

### Verze 0.76.0 alpha
* přidáno zobrazení vyplněných testů
* přidáno vyplňování nevyplněných testů
* přidán generátor testů
    * generování pouze otázek z jednoho tématického okruhu
    * nerozlišuje **veřejné** a **neveřejné** otázky
* přidáno GUI pro konfiguraci generátoru testů
* přidána komponenta pro uchovávání dat o uživateli a pro konfiguraci uživatele

*Obsahuje nedokončené funkcionality*

### Verze 0.75.0 alpha
* přidáno vkládání otázek
* přidáno přihlášení
* upravena struktura databáze

*Obsahuje nedokončené funkcionality!*