const QUESTION_INSERT_SIDSELECT = "sidselect";
const QUESTION_SEARCH_TOPIC = "search-topic";
const QUESTION_INSERT_TOIDSELECT = "toidselect";
const QUESTION_INSERT_API = "/api/ajax_topic_filter";

function get_topics(event)
{
    var target = event.target
    console.log("pica");
    // Configurate api
    switch(target.id)
    {
        case QUESTION_INSERT_SIDSELECT:
        var sidselect = target.value;
        var uri = QUESTION_INSERT_API + "?sidselect=" + encodeURIComponent(sidselect);
        break;

        case QUESTION_INSERT_TOIDSELECT:
        var sidselect = document.querySelector("#sidselect").value;
        var toidselect = target.value;
        var uri = QUESTION_INSERT_API + "?sidselect=" + encodeURIComponent(sidselect) 
                    + "&toname=" + encodeURIComponent(toidselect);
        break;

        case QUESTION_SEARCH_TOPIC:
        var toidselect = target.value;
        var uri = QUESTION_INSERT_API + "?toname=" + encodeURIComponent(toidselect);
        break;

        default:
        var uri = QUESTION_INSERT_API;
        break;
    }
    var xhr = new XMLHttpRequest();
    xhr.open("GET", uri);
    xhr.addEventListener("load", recieveData);
        
    // Function called at the end of the request
    function recieveData(e)
    {
        if(e.target.status == 200)
        {
            xhr_result = JSON.parse(xhr.responseText);
            console.log(xhr_result);
            
            update_toid_datalist(xhr_result.topics);

            validate_sidselect();
            validate_toidselect();
        }
    }
    xhr.send();  
}

// Updates datalist named toidselect_data
function update_toid_datalist(arr)
{
    datalist = document.querySelector("#toidselect_data");
    deleteChildren(datalist);
    arr.forEach(element => {
        var option = document.createElement("option");
        option.value = element;
        console.log(element);
        datalist.appendChild(option);
    });
    
}

// Deletes children from entered node
function deleteChildren(parentNode)
{
    while(parentNode.firstChild)
    {
        parentNode.removeChild(parentNode.firstChild);
    }
}

// Validates sidselect field of the form
function validate_sidselect()
{
    var sidselect = document.querySelector("#sidselect");
    if(sidselect)
    {

        if(sidselect.value == "")
        {
            var msg = "Prosím, zadejte název předmětu";
            error_message_box(sidselect, msg);
            return false;
        }

        // Validate if there are any topics
        else if(xhr_result.empty)
        {
            var msg = "Zadaný předmět neobsahuje žádná témata";
            error_message_box(sidselect, msg);
            return false;
        }

        // Validate subject from the server
        else if(!xhr_result.validSubject)
        {
            var msg = "Zadaný předmět neexistuje";
            error_message_box(sidselect, msg);
            return false;
        }
        else
        {
            var msg = "";
            error_message_box(sidselect, msg);
            return true;
        }   
    }
    
}

// Validates toidselect field of the form
function validate_toidselect()
{
    var toidselect = document.querySelector("#toidselect");
    
    if(toidselect)
    {
        // Validate if there are any topics
        if(xhr_result.empty)
        {
            var msg = "";
            error_message_box(toidselect, msg);
            return false;
        }
        else if(!toidselect.value)
        {
            var msg = "Prosím, zadejte název tématu otázky";
            error_message_box(toidselect, msg);
            return false;
        }
        else if(xhr_result.topics.indexOf(toidselect.value) == -1)
        {
            var msg = "Zadané téma neexistuje";
            error_message_box(toidselect, msg);
            return false;
        }
        else
        {
            var msg = "";
            error_message_box(toidselect, msg);
            return true;
        }
    }
}