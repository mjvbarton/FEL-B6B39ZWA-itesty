const STATE_ANSWER_TEXT = 1;
const STATE_ANSWER_OPT_TEXT = 2;
const ANSWER_TYPE_TEXT = "text";
const ANSWER_TYPE_OPT_TEXT = "opt_text";

// Loads event listeners and sets up the environment for Javascript
function load()
{
    load_answer_type_switch();

    console.log("Prdel");
    // Connecting events
    var form = document.querySelector("#question_insert");
    form.setAttribute("novalidate", "novalidate");
    form.addEventListener("submit", insertion_form_validation);   
    
    var sidselect = document.querySelector("#sidselect");
    sidselect.addEventListener("blur", get_topics);
    
    var toidselect = document.querySelector("#toidselect");
    toidselect.addEventListener("keyupp", get_topics);
    toidselect.addEventListener("blur", get_topics);

    var caption = document.querySelector("#q1 .caption");
    caption.addEventListener("blur", validate_caption);
    error_message_box(caption, "", true);

    var text_answer = document.querySelector("#qText input");
    text_answer.addEventListener("blur", validate_answer);
    error_message_box(text_answer, "", true);

    var answer_check_indicator = document.querySelector("#answer-right-indicator");
    answer_check_indicator.addEventListener("mouseover", show_answer_right_tooltip);
    answer_check_indicator.addEventListener("mouseout", hide_message_box);
    error_message_box(answer_check_indicator, "", true);

    for(i = 1; i <= 5; i++)
    {
        var text_answer = document.querySelector("#answer-" + i);
        text_answer.addEventListener("blur", validate_answers);
        error_message_box(text_answer, "", true);
    }

}

// This validates the caption of the question
function validate_caption(e)
{
    var caption = event.target;

    if(caption.value == "")
    {
        msg = "Prosím, zadejte hlavičku otázky";
        error_message_box(caption, msg);
        return false;
    }

    /*if(!caption.value.includes("?")) TODO: Make in the next version
    {
        msg = "Otázka musí obsahovat otazník";
        error_message_box(caption, msg);
        return false;
    }*/

    msg = "";
    error_message_box(caption, msg);
    return true;
    
}

// This validates the text answer of the question
function validate_answer(event)
{
    var answer = event.target;

    if(!answer.value)
    {
        msg = "Prosím, vyplňte text odpovědi";
        error_message_box(answer, msg);
        return false;
    }

    msg = "";
    error_message_box(answer, msg);
    return true;
    
}

// Shows error if the answer entered is invalid
function showAnswerError(answer)
{
    msg = "Prosím, vyplňte text odpovědi";
    error_message_box(answer, msg);
}

// Shows an error if the answer is invalid
function clearAnswerErrors(answers)
{
    answers.forEach(answer => {
        error_message_box(answer, "");
    });
}

// Validates answers -> checks if the answer was entered and if there are no gaps
function validate_answers(event)
{
    var activeAnswer = event.target;
    var id = activeAnswer.id;
    var number_id = id.split("-")[1];
    var toReturn = true;
    
    
    answers = [];
    for(i = 1; i <= 5; i++)
    {
        answers.push(document.querySelector("#answer-"+i));
    }

    clearAnswerErrors(answers);

    if(!answers[0].value)
    {
        showAnswerError(answers[0]);
        toReturn = false;
    }

    if(!answers[1].value)
    {
        showAnswerError(answers[1]);
        toReturn = false;
    }

    for(i = 3; i <= 5; i++)
    {
        var x = i;
        if((answers[i - 1].value) && (!answers[i - 2].value))
        {
            toReturn = check_previous_answer_filled(answers[i - 1]);
        }
    }

    if(toReturn)
    {
        clearAnswerErrors(answers);
    }
    else
    {
        event.preventDefault();
    }
    return toReturn;
    
}

// Sub-function -> checks if the previous answer was filled (this function is recursive)
function check_previous_answer_filled(answer, errorState = false)
{
    var activeAnswer = answer;
    var id = activeAnswer.id;
    console.log(id);
    var number_id = id.split("-")[1];
    //var previousAnswer = document.querySelector("#answer-" + (number_id  - 1));

    if(number_id > 1)
    {
        var previousAnswer = document.querySelector("#answer-" + (number_id  - 1));
        if(!previousAnswer.value)
        {
            showAnswerError(previousAnswer);
            return check_previous_answer_filled(previousAnswer);
        }
        else
        {
            return false;
        }
    }
    return false;

}

// Shows answer right tooltip at the formield element
function show_answer_right_tooltip(event)
{
    var msg = event.target.title;
    info_message_box(event.target, msg);
}

// Validates the insertion form
function insertion_form_validation(event)
{

    var blurEvent = new Event("blur");
    var answer_check_indicator = document.querySelector("#answer-right-indicator");

    elements = [
        document.querySelector("#sidselect"),
        document.querySelector("#toidselect"),   
        document.querySelector("#q1 .caption"),
    ];

    var selector = document.querySelector("#qSelect select");
    switch(selector.value)
    {
        case ANSWER_TYPE_TEXT:
        elements.push(document.querySelector("#qText input"));
        break;

        case ANSWER_TYPE_OPT_TEXT:
        for(i = 1; i <= 5; i++)
        {
            elements.push(document.querySelector("#answer-" + i));
        }
        break;

        default:
        event.preventDefault();
        break;        
    }

    elements.forEach(element =>
        {
            if(!element.dispatchEvent(blurEvent))
            {
                event.preventDefault();                
            }
        }
    );

    error_message_box(answer_check_indicator, "");
    if(!checkAnswersChecked("answer-right-"))
    {
        event.preventDefault();
        error_message_box(answer_check_indicator, "Prosím, zaškrtněte správnou odpověď");
    }


}