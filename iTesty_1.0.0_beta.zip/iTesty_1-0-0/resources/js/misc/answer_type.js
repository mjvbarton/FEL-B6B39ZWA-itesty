// QUESTION INSERT - Answer type handling
//
// Function which will be called onLoad()
function load_answer_type_switch() 
{
    // Hides refresh button
    var btn_refresh = document.querySelector("#q1select_noJS");
    hideElement(btn_refresh);

    // Adding event listener to selector
    var selector = document.querySelector("#qSelect");
    selector.addEventListener("change", showQuestionType);

    selectorState = 0;

}

// Function which decides if display 'text' | 'opt_text' abilitty
function showQuestionType(event)
{
    var target = event.target;
    var show_state = target.value;
    selectorState = show_state;
    var formText = document.querySelector("#qText");
    var formOptText = document.querySelector("#qOptText");
    var buttons = document.querySelector("#qButtons");

    switch(show_state)
    {
        default:
            hideElement(formText, formOptText, buttons);
            break;
        
        case "text":
            hideElement(formText, formOptText, buttons);
            showElement(formText, buttons);
            break;
        
        case "opt_text":
            hideElement(formText, formOptText, buttons);
            showElement(formOptText, buttons);
            break;
    }    
}

