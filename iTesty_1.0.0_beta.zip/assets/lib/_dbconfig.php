<?php
    // Before first start set right credentials for the database
    const SQL_HOST = "innodb.endora.cz";
    const SQL_USR = "itesty";
    const SQL_PW = "MyCguwkVwY5LJEP";
    const SQL_DB = "itesty1";

    // Global PDO object used by models
    global $db;
    $db = new PDO("mysql:host=".SQL_HOST.";dbname=".SQL_DB.";charset=utf8mb4", SQL_USR, SQL_PW);
?>