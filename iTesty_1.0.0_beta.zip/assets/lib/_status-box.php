<?php

//Basic configuration
const STATUSBOX_TYPE_DEFAULT = "";
const STATUSBOX_TYPE_SUCCESS = "success";
const STATUSBOX_TYPE_WARNING = "warning";
const STATUSBOX_TYPE_WRONG = "wrong";

const STATUSBOX_TEXT_DELIMITER = "|";

//Status box class for displaying status messages
class StatusBox
{
    public function __construct(string $message, string $type = STATUSBOX_TYPE_DEFAULT)
    {
        $this->message = $message; // Status message that will be displayed in StatusBox
        $this->type = $type; // CSS class of dialog

        switch($type)
        {
            case STATUSBOX_TYPE_SUCCESS:
            $this->caption = "Úspěch!"; // Caption of the StatusBox
            break;

            case STATUSBOX_TYPE_WARNING:
            $this->caption = "Upozorění:"; // Caption of the StatusBox
            break;

            case STATUSBOX_TYPE_WRONG:
            $this->caption = "Chyba!"; // Caption of the StatusBox
            break;

            default:
            $this->caption = "Informace"; // Caption of the StatusBox
            break;
        }
    }

    public function show() 
    {
        ?>
    <div class="status-box <?php echo $this->type; ?>">
        <strong><?php echo $this->caption;?> </strong>
        <?php echo $this->message ?>
    </div>
<?php
    }
}