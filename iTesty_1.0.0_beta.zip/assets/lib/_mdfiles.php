<?php
    // This library is for including Markdown files
    // It works along with Parsedown
    include_once("extlib/Parsedown/Parsedown.php");
    
    //$md_docRoot = $_SERVER["DOCUMENT_ROOT"];
	$md_docRoot = DOCUMENT_ROOT;
    
    const STATIC_PATH = "resources/md/";

    // This function will print html extracted from Markdown file
    // The functionality works similar to native php include()
    function include_mdfile(string $file_path)
    {
        $path = DOCUMENT_ROOT.STATIC_PATH.$file_path;

        if(file_exists($path))
        {
            $parsedown = new Parsedown();
            echo $parsedown->text(file_get_contents($path));
            return true;
        }
        return new ErrorException("File does not exist", 404);
    }