<?php


// This function parses URL for the front controller
function parseUri($params, $default_controller = "guest", $default_action = "action_default") : array {
	$to_return = array(0 => $default_controller, 1 => $default_action, 2=>array());
	
	@list($controller, $action, $pars) = explode("/", $params, 3);
	
	if((isset($controller)) && !($controller == "")) {
		$to_return[0] = $controller;
	}
	if (isset($action)) {
		$to_return[1] = $action;
	}
	if (isset($pars)) {
		$to_return = array_merge($to_return ,explode("/", $pars));
	}	
	
	return $to_return;
 }

 // This function returns an array from $_GET values and performs the conversion to string or int
 function readGetParams() : array
 {
	$filter_params = array();
    foreach($_GET as $key => $value)
    {
        if($key == "page")
        {
			continue;
		}

        $filter_params[$key] = !((int) $value) ? trim((string) $value) : (int) $value;
	}	
	return $filter_params;
 }
 
