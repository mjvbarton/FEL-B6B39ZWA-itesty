<?php
// Checking the availability of the DB
$db = isset($GLOBALS["db"]) ? $GLOBALS["db"] : null;
if(!isset($db))
{
    raise_error(ERROR_DB_NOT_FOUND);
}

// Get required models
include_once("models/_topic_handling.php");

// Class for storing subjects info
class iTestSubject
{
    // Loads subject data from MYSQL database based on subject id
    public function __construct($sid)
    {
        $this->sid = $sid;

        // Preparing sql query
        $this->db = $GLOBALS["db"];
        $sql = "SELECT name, description FROM subjects WHERE sid=:sid AND enabled=1";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(":sid", $this->sid);

        if(!$stmt->execute())
        {
            raise_error(ERROR_DB_QUERY_FAIL);
        }
        
        // Loading data
        if($row = $stmt->fetch())
        {
            $this->name = $row['name'];
            $this->description = $row['description'];
        }
        
        $this->topics = $this->get_topics();
    }

    // Returns topics based on sid. The result can be returned as array with toids or iTestTopic objects
    public function get_topics(bool $get_objects = true)
    {
        $sql = "SELECT topics.toid FROM topics WHERE topics.sid = :sid AND enabled=1 ORDER BY topics.name, topics.toid";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(":sid", $this->sid);
        
        if(!$stmt->execute())
        {
            raise_error(ERROR_DB_QUERY_FAIL);
        }

        $result = array();
        while($row = $stmt->fetch())
        {
            if($get_objects)
            {
                $result[] = new iTestTopic($row["toid"]);
            }
            else
            {
                $result[] = $row["toid"];
            }
        }

        $toReturn = !($result) ? array() : $result;
        return $toReturn;

    }

    public function get_topic_by_name(string $topic_name)
    {
        if($this->topics)
        {
            foreach($this->topics as $topic)
            {
                if($topic->name == $topic_name)
                {
                    return $topic;
                }
            
            }
            return null;
        }
        return null;
    }

    public function get_topic_by_toid(int $toid)
    {
        if($this->topics)
        {
            foreach($this->topics as $topic)
            {
                if($topic->toid == $toid)
                {
                    return $topic;
                }
            
            }
            return null;
        }
        return null;
    }
}

// Conatins methods for handling multiple subjects
class iTestSubjectContainer
{
    public function __construct(array $object_array = array(), int $iid = 1)
    {
        $this->iid = $iid; // ID of institution -> this functionality is prepared for further versions of the app
        $this->subjects = !($object_array) ? $this->load_subjects() : $object_array; // Data list of iTestSubject objects
        $this->db = $GLOBALS["db"]; // PDO object
    }

    // Loads subjects into container
    private function load_subjects()
    {
        $db = $GLOBALS["db"];
        $sql = "SELECT sid FROM subjects WHERE iid = :iid AND enabled=1 ORDER BY name, sid";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(":iid", $this->iid);

        if(!$stmt->execute())
        {
            return false;
        }

        $result = array();
        while($row = $stmt->fetch())
        {
            $result[] = new iTestSubject($row["sid"]);
        }

        $toReturn = !($result) ? null : $result;
        return $toReturn;
    }

    // Returns iTestSubject object from object list according to subject name or sid
    public function subject($key)
    {
        if(is_string($key))
        {
            return $this->get_subject_by_name($key);
        }

        else if(is_int($key))
        {
            return $this->get_subject_by_sid($key);
        }

        return null;
    }

    // Returns iTestSubject object from object list according to subject name
    private function get_subject_by_name(string $name)
    {
        foreach($this->subjects as $subject)
        {
            if($subject->name == $name)
            {
                return $subject;
            }
        }
        return null;
    }

    // Returns iTestSubject object from object list according to its id
    private function get_subject_by_sid(int $sid)
    {
        foreach($this->subjects as $subject)
        {
            if($subject->sid == $sid)
            {
                return $subject;
            }  
            
        }
        return null;
    }
}