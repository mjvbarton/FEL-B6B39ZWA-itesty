<?php

// Checking the availability of the DB
$db = isset($GLOBALS["db"]) ? $GLOBALS["db"] : null;
if(!isset($db))
{
    raise_error(ERROR_DB_NOT_FOUND);
}

//Class for storing information about answers
class Answers {
    public function __construct(int $aid, string $text)
    {
        $this->text = $text; // Text of the answer
        $this->id = $aid; // Id of answer
        $this->isCorrect = -1; // State of answer -1 not filled | 0 wrong | 1 correct
        $this->checked = false;
    }
    public function check(){
        $this->checked = true;
    }
}


//Value stored in linked list of questions
class Question {
    function __construct(int $qid, int $isCorrect = -1) {
        $this->qid = $qid; //Question id in DB
        $this->evaluated = false; //Check if the question was evaluated
        $this->isCorrect = -1; // State of question
        
        //Setting up MYSQL connection
        $this->db = $GLOBALS["db"];
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        //Getting data about question
        $sql = "
            SELECT heading, description, answer_type, answer_right, answer_count, 
            answer1, answer2, answer3, answer4, answer5 FROM questions WHERE qid = :qid
            ";
        $stmt = $this->db->prepare($sql);
        if(!$stmt->execute([":qid" => $this->qid]))
        {
            raise_error(ERROR_DB_QUERY_FAIL);
        };

        //Assigning properties to values from db
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $this->head = $row['heading']; //Displayed text of the question
            $this->desc = $row['description']; //Additional description (optional)
            $this->answer_type = $row['answer_type']; //Type of answer --> for version 1.0 available just (text, opt_text)
            $this->answer_right = $row['answer_right']; //Index of correct answer
            $this->answers = array(); // Array of answers (represented as string)
            for($i = 1; $i <= (int) $row['answer_count']; $i++){
                $this->answers[$i] = new Answers($i, $row["answer".$i]);
            }
        }              
            $this->usr_answer = null; //Answer got by user
            $stmt->closeCursor();
    }

    // Executes evaluation subfunctinons based on Question->answer_type
    public function evaluate($got_answer) {
        $this->evaluated = true;
            
        switch($this->answer_type) {
            case 'text':
                $this->evaluateText((string) $got_answer);
                break;

            case 'opt_text':
                $this->evaluateOpt((string) $got_answer);
                break;

            default:
               raise_error("Špatné formátování dat");
        }
    }

    //Evaluates question with options
    private function evaluateOpt($got_answer_id) {
        if($got_answer_id == 0)
        {
            foreach($this->answers as $answer)
            {
                $answer->isCorrect = 0;
            }
            $this->answers[$this->answer_right]->isCorrect = 1;
            $this->isCorrect = 0;
        }
        else
        {
            $got_answer = $this->answers[$got_answer_id]; //Got answer object
            $got_answer->check();
            if($got_answer_id == $this->answer_right){
                $got_answer->isCorrect = 1;
                $this->isCorrect = 1;
            }
            else
            {
                $got_answer->isCorrect = 0;
                $this->answers[$this->answer_right]->isCorrect = 1;
                $this->isCorrect = 0;
            }
        }
    }

    //Evaluates question with text input
    private function evaluateText(string $got_answer_text) {
        $this->usr_answer = trim($got_answer_text);
        $obj_answer = $this->answers[1];
        $correct_answer_text = $obj_answer->text;
        if($correct_answer_text == $got_answer_text){
            $obj_answer->isCorrect = 1;
            $this->isCorrect = 1;
        }
        else{
            $obj_answer->isCorrect = 0;
            $this->isCorrect = 0;
        }
    }
    // Returns qid is correct
    public function getIdOfCorrect(){
        if($this->isCorrect == 1){
            return $this->qid;
        }
    }
    
    // Blocks form input if
    public function blockFormInput(){
        if($this->evaluated){
            return "disabled";
        }
    }
}

// Nodes of question linked list
class Node {
    function __construct($nextNode,  $data)
    {
        $this->nextNode = $nextNode;
        $this->data = $data;
    }
}

// Class of question queue which 
class QuestionQueue {
    function __construct() {
        $this->head = null;
    }

    //This will insert values to linked list from an array
    function initFromArray(array $qids){
        foreach($qids as $qid) {
            $this->insert($qid);
        }
    }

    // Implemented insert method of linked list
    public function insert($qid) {
        //Checking if it will create new data object or it will use the existing one
        if((is_integer($qid)) || (is_string($qid))){
            $dataObject = new Question($qid); //Creates new question object
        }
        elseif((is_object($qid)) && (get_class($qid)=="Node") ){
            $dataObject = $qid->data;
        }
        else{
            raise_error(ERROR_WRONG_DATA_FORMAT); //Dies if the argument is not an object or an integer
        }
        if(!$this->head){
            $this->head = new Node(null, $dataObject);
        }
        else {
            $cursor = $this->head;
            while($cursor->nextNode){
                $cursor = $cursor->nextNode;
            }
            $cursor->nextNode = new Node(null, $dataObject);

        }
    }
    //Pops the first element of linked list (FIFO)
    public function pop() {
        if($this->head) {
            $outNode = $this->head;
            $this->head = $this->head->nextNode;
            return $outNode;
        }
        else{
            return null;
        }
    }
}