<?php

    include_once("models/_question_inserting.php");
    include_once("models/_topic_handling.php");
    include_once("models/_subject_handling.php");

    // Configuration
    const QUESTION_INSERT_MSG_SUCCESS = "Otázka byla přidána.";
    
    $formfields = new FormFieldContainer();
    $subjects = new iTestSubjectContainer();
    $subject = null;

    $_POST["isPublic"] = 1; // TODO: Remove this in the next version

    // If there is subject and topic in session simulate POST
    if((isset($_SESSION["last_subject"])) && (isset($_SESSION["last_topic"])))
    {
        $_POST["sidselect"] = $_SESSION["last_subject"];
        $_POST["toidselect"] = $_SESSION["last_topic"];
        //$_POST["isPublic"] = $_SESSION["last_isPublic"];
        //$_POST["isValid"] = $_SESSION["last_isValid"];

        // Free the memory
        $_SESSION["last_subject"] = $_SESSION["last_topic"] = null;
    }
    
    $subject = $subjects->subject(isset($_POST["sidselect"]) ? trim($_POST["sidselect"]) : "");

    // Getting topic
    if(isset($subject))
    {
        if(isset($_POST["toidselect"]))
        {
            $formfields->add_field(new Formfield("sidselect", "25", FORMFIELD_METHOD_POST, true));
            $formfields->add_field(new Formfield("toidselect", "25", FORMFIELD_METHOD_POST, true));
            $formfields->validate_fields();
        }
    }
    
    // Form validation
    $errors = array();
    if(isset($_POST['addQuestion']))
    {   
        // Redirecting if cancel button was hit
        if($_POST['addQuestion'] < 0)
        {
            echo "Canceled. Redirect to wizardstart.php";
            exit();
        }

        // Getting form fields
        $formfields->init_from_array([
            new Formfield("caption", 150, FORMFIELD_METHOD_POST, true),
            new Formfield("description", 150, FORMFIELD_METHOD_POST, false),
            new Formfield("isPublic", 5, FORMFIELD_METHOD_POST, false),
            new Formfield("sidselect", 25, FORMFIELD_METHOD_POST, true),
            new Formfield("toidselect", 25, FORMFIELD_METHOD_POST, true)
        ]);

        // Get answer_type        
        if(isset($_POST["answer_type"]))
        {
            switch($_POST["answer_type"])
            {
                case "text":
                $formfields->add_field(new Formfield("answer_right", 5, FORMFIELD_METHOD_FORCE_SET, false, false, false, 1));
                $_POST["answers"] = [$_POST["answer1"]];
                break;

                case "opt_text":
                $formfields->add_field(new Formfield("answer_right", 5, FORMFIELD_METHOD_POST, true, true));
                break;

                default:
                $_POST["answer_type"] = "text";
                $formfields->add_field(new Formfield("answer_right", 5, FORMFIELD_METHOD_FORCE_SET, false, false, false, 1));
                $_POST["answers"] = [$_POST["answer1"]];
                break;
            }
            $formfields->add_from_fieldgroup("answers", "answer",
            [
                "max_length" => 50,
                "checkable" => false,
                "selectable" => false
            ], true);

            // Check if inserted subject is subject list
            if(!formfields_validate_existing_subject($formfields, $subjects))
            {
                $formfields->field("sidselect")->custom_error_msg("Zadaný předmět neexistuje");
            }
            
            // Check if inserted topic is in subject
            if(!formfields_validate_topic_in_subject($formfields, $subject))
            {
                $formfields->field("toidselect")->custom_error_msg("Zadaný předmět neobsahuje toto téma");
            }

            // Insert data into DB if there are no errors
            if(($formfields->validate_fields()) && ($_POST["addQuestion"] > 0))
            {
                insertQuestion(
                    $subjects->subject($formfields->field("sidselect")->get_value(false))->sid, 
                    $subject->get_topic_by_name($formfields->field("toidselect")->get_value(false))->toid, 
                    $_SESSION["uid"], 
                    $formfields->field("caption")->get_value(false), 
                    $formfields->field("description")->get_value(false),
                    $_POST["answer_type"],
                    $formfields->get_data_from_field_group("answer"),
                    $formfields->field("answer_right")->get_value(false),
                    $formfields->field("isPublic")->get_value(false)
                );
                add_statusbox_to_session(STATUSBOX_TYPE_SUCCESS, QUESTION_INSERT_MSG_SUCCESS);
                
                // Redirect after insertion
                switch($_POST["addQuestion"])
                {
                    case "2":
                    preserve_subject_topic_isPublic(
                        $formfields->field("sidselect")->get_value(false),
                        $formfields->field("toidselect")->get_value(false),
                        $formfields->field("isPublic")->get_value(false));
                    header("Location: /question/insert/");
                    exit();
                    break;

                    case "1":
                    header("Location: /");
                    exit();
                    break;
                }
            }
        }
    }
    // Including the view
    include("views/itest/_question_insert_page.php");
    
    