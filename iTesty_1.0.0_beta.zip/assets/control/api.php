<?php

    // This function handles ajax topic filter API
    function ajax_topic_filter(array $todo)
    {
        include("control/api/ajax_topic_filter.php");
    }