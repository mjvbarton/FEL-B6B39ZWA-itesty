<?php
    // Load test creation if user is logged in or header to home
    function action_default(array $todo)
    {

        if(isset($_SESSION["uid"]))
        {
            header("Location: /test");
            exit();
        }
        else
        {
            header("Location: /");
            exit();
        }
    }

    function logout(array $todo)
    {
        if(isset($_SESSION["uid"]))
        {
            session_unset();
            session_destroy();
            add_statusbox_to_session(STATUSBOX_TYPE_DEFAULT, "Byli jste odhlášeni ze systému");
            header("Location: /");
            exit();
        }
    }

    // This function shows filled tests
    function tests(array $todo)
    {
        include("models/_test_handling.php");
        
        // Validation of GET
        $filter_params = readGetParams();
        
        $testFilter = new iTestFilter($_SESSION["uid"], $filter_params);
        $subjects = new iTestSubjectContainer();                
        
        if(isset($_GET["page"]) && is_int((int) $_GET["page"]))
        {
            $uri = explode("?", $_SERVER["REQUEST_URI"]);
            $paginationAction = isset($uri[1]) ? $uri[1] : "";
            $testFilter->page_num = (int) $_GET["page"];
            if(!$testFilter->check_page_num())
            {
                header("Location: /user/tests");
                exit();
            }
        }
        if(isset($_GET["filter"]))
        {
            
        }
        $testFilter->enable_pagination();
        $testFilter->load_tests();
        include("views/itest/_written_tests_page.php");
    }

    // Show user profile
    function profile(array $todo)
    {
        include_once("models/_user_handling.php");
        $user = new User($_SESSION["uid"]);
        
        include("views/user/_view_profile_page.php");
    }