<li></li>
<li><a href="/help" target="_blank"><i class="fa fa-question-circle">&nbsp;</i>Nápověda</a></li>