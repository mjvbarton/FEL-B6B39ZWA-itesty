<?php
    // This file contains functions which render forms for test generator settings

    // Including necessary scripts
    include("views/misc/_pagination.php");

    // Converts value in array to input
    function parse_array_to_input( $formfield_with_array, string $input_type = "hidden")
    {
        if(is_array($arr = $formfield_with_array->get_value(false, true)))
        {
            foreach($arr as $element)
            {
                $value = htmlspecialchars($element);
                echo "<input type='$input_type' name='{$formfield_with_array->name}[]' value='$value'/>";
            }
        }
    }


    // Gets the maximum of available questions which can be inserted into test generator
    // This funcion also creates option list for <select>
    function get_max_question_count(int $questions_total, $echo_on = true) : int
    {
        if($questions_total <= 10)
        {
            return ITEST_MIN_QUESTIONS_ALLOWED;
        }

        for($i = 10; $i <= ITEST_MAX_QUESTIONS_ALLOWED; $i = $i + 10)
        {
            if($questions_total < $i)
            {
                return ($i - 10);
            }
            if($echo_on)
            {
                echo "<option value='$i'>$i</option>";
            }
        }
        return ITEST_MAX_ANSWERS_ALLOWED;
    }

    // Gets the number of all available questions
    function count_all_questions( $subject) : int
    {
        $toReturn = 0;

        if(isset($_POST["toid"]))
        {
            foreach($_POST["toid"] as $toid)
            {
                if($topic = $subject->get_topic_by_toid((int) $toid))
                {
                    $toReturn += $topic->count_questions;
                }
            }
        }
        
        return $toReturn;
    }

    // Renders form for searching topics
    function render_search_topic($topicFilter)
    {
?>  
    <!-- Test search bar -->

    <div class="itest topic topic-search">
        <form id="topic-filter-form" action="/test/generator/<?php echo $topicFilter->sid; ?>" method="get">
            <div class="formfield">
                <label>
                    Vyhledat téma:
                    <input id="search_topic" class="formfield text-input" type="text" name="toname" list="toidselect"
                    value="<?php echo isset($_GET["toname"]) ? htmlspecialchars($_GET["toname"]) : ""; ?>" autocomplete="off"/>
                    <datalist id="toidselect">
                    <?php
                        foreach($topicFilter->topics as $topic)
                        {
                            echo "<option value='$topic->name'>";
                        }
                    ?>
                    </datalist>
                </label>
                <button class="formfield btn" type="submit" value="search_topic">
                    <i class="fa fa-search"></i><span class="hide-me">Vyhledat</span>
                </button>
            </div>
            <div class="formfield">
                <label>
                    Ročník:
                    <input id="class-select" type="number" name="class" min="<?php echo CLASS_MIN; ?>" max="<?php echo CLASS_MAX; ?>" class="formfield text-input number" <?php echo isset($_GET["class"]) && $_GET["class"] > 0? "value='".htmlspecialchars($_GET["class"])."'" : ""; ?>/>
                </label>
            </div>
            <div class="formfield">
                <label class="formfield radio-field small">
                    <input id="toggle-all-class" type="checkbox" name="allclass" value="0" <?php echo !isset($_GET["class"]) || $_GET["class"] == "0" ? "checked" : ""; ?>/>
                    <span class="checkmark radio-input small" ></span>
                    všechny ročníky
                </label>
            </div>
            <div class="formfield">
                <button class="formfield btn" type="submit" name="filter" value="filter">
                    <i class="fa fa-filter"></i><span class="hide-me">Filtr</span>
                </button>
            </div>
        </form>
    </div>

<?php
    }

    // Renders form for selecting topics
    function render_topic_select($topicFilter, $formfields, $toids = array())
    {
                
        if(($formfields->field("toid")) && ($formfields->field("toid")->get_error()))
        {
            $statusBox = new StatusBox("Nevybrali jste žádné téma", STATUSBOX_TYPE_WARNING);
            $statusBox->show();
        }
?>
        <!-- Topic selector form -->

        <div class="topic-select">
            <?php render_search_topic($topicFilter); ?>
            <form id="topic-select-form" action="/test/generator/<?php echo $topicFilter->sid; ?>" method="post" data-max-elements="<?php echo iTestTopicFilter::COUNT_TOPICS_PER_PAGE; ?>">
                <input type="hidden" name="sid" value="<?php echo $topicFilter->sid; ?>">
                <input type="hidden" name="toid[]" value="-1">
                <table class="itest-table structure">
                    <thead>
                        <tr>
                            <td class="itest-table cell cell-text">
                                Název tématu:
                            </td>
                            <td class="itest-table cell cell-text">Vytvořil:</td>
                            <td class="itest-table cell cell-numeric">Počet otázek:</td>
                            <td class="itest-table cell cell-numeric">Ročník:</td>
                        </tr>
                    </thead>
                <?php
                    if($topicFilter->empty)
                    {
                ?>
                    <tbody>
                    <tr>
                        <td colspan="4" class="itest-table cell cell-text"><em>Nebylo nalezeno žádné téma</em></td>
                    </tr>
                    </tbody>
                    </table>
                    </form>
                    </div>

                <?php        
                        return;
                    }
                ?>
                    <tbody>
                        <?php
                            $i = 1;                            
                            foreach($topicFilter->topics as $topic)
                            {
                                $disabled = !($topic->count_questions < ITEST_MIN_QUESTIONS_ALLOWED) ? "" : "disabled";
                        ?>
                        <tr>
                            <td class="itest-table cell cell-text">
                                <label class="formfield radio-field small <?php echo $disabled; ?>">
                                    <input type="radio" id="<?php echo "topic-$i"?>" name="toid[]" value="<?php echo $topic->toid; ?>" <?php echo $disabled; ?>>
                                    <span class="checkmark radio-input small"></span>
                                    <?php echo $topic->name; ?>
                                </label>
                            </td>
                            <td class="itest-table cell cell-text"><em><?php echo isset($topic->creator) ? $topic->creator : "správce" ?></em></td>
                            <td class="itest-table cell cell-numeric"><?php echo $topic->count_questions; ?></td>
                            <td class="itest-table cell cell-numeric"><?php echo $topic->class; ?></td>                            
                        </tr>
                        <?php
                            $i++;
                            }
                        ?>
                    </tbody>
                </table>
            </form>
            <div id="table-pagination">
                <?php renderTestPagination($topicFilter, "topic-filter-form"); ?>
            </div>
            <div class="formfield">
                <button type="submit" name="set_params" form="topic-select-form" value="set_params" class="formfield btn btn-submit">Pokračovat &nbsp;<i class="fa fa-arrow-right"></i></button>
            </div>
        </div>

<?php
    }

    // Renders form for setting test parameters
    function render_test_params($subject, $formfields)
    {
?>
            <form action="/test/generator/<?php echo $subject->sid; ?>" method="post">
                <input type="hidden" name="sid" value="<?php echo $subject->sid; ?>" />
                <?php parse_array_to_input($formfields->field("toid")); ?>

                <div class="itest test-config formfield">
                    <label>
                            Počet otázek v testu:
                        <input type="hidden" name="question_count" value="<?php echo ITEST_MIN_QUESTIONS_ALLOWED ?>">
                        <select name="question_count" class="formfield text-input">
                            <option value="<?php echo ITEST_MIN_QUESTIONS_ALLOWED ?>"><?php echo ITEST_MIN_QUESTIONS_ALLOWED ?></option>
                            <?php get_max_question_count(count_all_questions($subject)); ?>
                        </select>
                    </label>
                </div>
                <div class="formfield">
                    <button type="submit" name="generate" value="generate" class="formfield btn btn-submit">Pokračovat &nbsp;<i class="fa fa-arrow-right"></i></button>
                </div>
            </form>
          
  
<?php
    }