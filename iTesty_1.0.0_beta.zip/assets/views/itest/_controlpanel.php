<?php
    // Formats itest time created
    function get_time_created( $itest)
    {
        $time = strtotime($itest->time_created);
        echo date("j.m.Y G:i", $time);
    }

    // Formats itest evaluation result
    function get_itest_corrected( $itest, $element = "span", $classList = "formfield")
    {
        if($itest->evaluated)
        {
            $evaluation_result = round($itest->get_evaluation_result()*100);
            if($evaluation_result == 0) 
            {
                $status = "wrong";
            }
            else
            {
                $status = "success";
            }
            echo "<$element class='$classList $status'>$evaluation_result% správně</$element>";
        }
        else
        {
            echo "<$element class='$classList'><em>nehodnoceno</em></$element>";
        }
    }

    // View test info for #sidebar
    function control_panel_show_mode($itest, $closed = "</div>") 
    {
?>
        <div class="sidebar-left info-box">
            <h2>Informace o testu</h2>
            <div>
            <table>
                    <tr>
                        <th>ID testu:</th>
                        <td><?php echo $itest->name; ?></td>
                    </tr>
                    <tr>
                        <th>Předmět:</th>
                        <td><?php echo $itest->subject->name; ?></td>
                    </tr>
                    <tr>
                        <th>Vytvořeno:</th>
                        <td><?php echo get_time_created($itest); ?></td>
                    </tr>
                    <tr>
                        <th>Hodnocení:</th>
                        <td><?php get_itest_corrected($itest); ?></td>
                    </tr>
                </table>
<?php
        echo $closed. " ". $closed;
    }

    // View test info for #sidebar with control buttons
    function control_panel_fill_mode($itest)
    {
        control_panel_show_mode($itest, null);
?>
        <button id="itest-form-submit" class="formfield btn btn-submit" type="submit" form="itest-form" name="submit-test" value="submit-test"><i class="fa fa-check-square-o"></i>&nbsp;Vyhodnotit</button><!--</label>-->
        <button id="itest-form-reject" class="formfield btn btn-quit" type="submit" form="itest-form" name="reject-test" value="reject-test"><i class="fa fa-close"></i>&nbsp;Opustit test</button>
    </div></div>
<?php

    }

    // This function renders subjects for the test generator set page
    function generator_subjects($subjects)
    {
        if((isset($subjects)) && ($subjects->subjects))
        {
?>
    <div class="sidebar-left menu-left">
        <h2>Předměty</h2> 
        <ul>
        <?php
            foreach($subjects->subjects as $subject)
            {
                ?>
                    <li>
                        <a href="/test/generator/<?php echo $subject->sid; ?>">
                            <?php echo $subject->name; ?>
                        </a>
                    </li>        
                <?php
            }
        ?>
        </ul>
    </div>
<?php    
        return;    
        }
        echo "Žádný předmět nenalezen";
    }