<?php 
include("views/itest/_generator_forms.php");
include("views/itest/_controlpanel.php");
include("views/static/_header.php");

?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    
    <title>iTesty - Nový test</title>

    <link rel="stylesheet" href="/resources/css/main.css" media="screen">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/resources/css/noprint.css" media="print">
    <script src="/resources/js/control/topic_filter.js"></script>
    <script src="/resources/js/misc/form_functions.js"></script>
    <script src="/resources/js/misc/error_rendering.js"></script>
</head>

<body>

    <!-- Top menu bar -->

    <?php get_header("_topmenu-user"); ?>
    
    <!-- Side menubar -->

    <nav id="sidebar-left">
    <?php generator_subjects($subjects)?>
        <hr class="hide-separator" />
    </nav>

    <!-- Header of current page -->

    <header>
        <h1>Generovat test</h1>
        <hr class="hide-separator" />
    </header>

    <!-- Page content -->
    
    <main id="page">
        <?php 
            // Show test parameters
            if($setgen_mode == SETGEN_MODE_PARAMS)
            {
?>  
        <!-- Test parameters -->

        <section class="itest test-config" id="itest-config">
            <h2>Parametry testu (<?php echo $subject->name; ?>)</h2>

<?php           
                statusBox_from_session();
                render_test_params($subject, $formfields);
?>
        </section>
<?php
            }

            // Show topic selection
            else
            {
        ?>

        <!-- Topic selection -->

        <section id="itest-topic">
            <h2>Dostupná témata (<?php echo $subject->name; ?>)</h2>
            <?php
                statusBox_from_session();
                render_topic_select($topicFilter, $formfields);
            ?>
        </section>
        <?php
            }
        ?>
    </main>

    <!-- Footer -->
    <footer id="bottombar">
    <?php include("views/static/_footer.php"); ?>
    </footer>

    <script>
        <!--
            load();
        -->
    </script>
</body>
</html>