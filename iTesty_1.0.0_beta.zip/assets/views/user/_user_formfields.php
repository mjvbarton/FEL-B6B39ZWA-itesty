<?php

//Loading formfields library
include_once("lib/_formfields.php");

// Gets error message from fieldlist of formfields
function get_error( $formfields, string $name)
{
    if($formfields->field($name))
    {
        return $formfields->field($name)->get_error();
    }
    else
    {
        return null;
    }
}

// Shows error message at the fields
function showErrorMessage(string $msg)
{
    if($msg)
    {
        return "<span class='formfield message-box'>$msg</span>";
    }
    return "";
}

// Renders login form
function renderLoginForm( $formfields)
{
?>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" id="login-form">
        <fieldset class="itest option">
            <h2><i class="fa fa-lock">&nbsp;</i>Přihlášení</h2>
            <p>Pro přístup k testům je potřeba se přihlásit.</p>

            <!-- Usermail -->
            <div class="formfield" id="usermail">
                <label class="formfield label">Email:
                <input class="login-text formfield text-input" type="email" name="usermail" maxlength="50" placeholder="např. josef@priklad.com ..." required="required" data-parent-id="usermail"/>
                <?php echo (get_error($formfields, "usermail")) ? showErrorMessage(get_error($formfields, "usermail")) : ""; ?>
                </label>
            </div>
            
            <!-- Password -->
            <div class="login formfield" id="userpw">
                <label class="formfield label">Heslo:
                <input class="login-text formfield text-input" type="password" name="userpw" maxlength="50" placeholder="*********" pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).*$" required="required" data-parent-id = "userpw"/>
                <?php echo (get_error($formfields, "userpw")) ? showErrorMessage(get_error($formfields, "userpw")) : ""; ?>
                </label>
            </div>

            <div class="formfield">
                <button type="submit" form="login-form" name="submit_login" value="login" class="formfield btn btn-submit"><i class="fa fa-sign-in">&nbsp;</i>Přihlásit se</button>
                <span id="login-form-status" class="formfield"></span>
            </div>
        </fieldset>
    </form>
<?php
}