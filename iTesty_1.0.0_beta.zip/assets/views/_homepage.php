<?php
    include("views/static/_header.php");
    include("views/user/_user_formfields.php");
    include_once("lib/_status-box.php");
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    
    <title>iTesty</title>

    <link rel="stylesheet" href="resources/css/main.css" media="all">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--<link rel="stylesheet" href="resources/css/print.css" media="print">-->
    <script src="resources/js/control/login.js"></script>
    <script src="/resources/js/misc/error_rendering.js"></script>
    
</head>

<body>
    <!-- Top menu bar -->

    <?php get_header("_topmenu-guest") ?>;
    
    <!-- Header of current page -->

    <header>
        <h1>Homepage</h1>
        <hr class="hide-separator" />
    </header>

    <?php
        // Status box from _app_state.php
        statusbox_from_session();
    ?>

    <!-- Login form -->

    <main id="page" class= "no-sidebar">
        <section id="login-box">
            <?php renderLoginForm($formfields); ?>
        </section>

        <!-- Short page about -->

        <section class="content-static" id="home-about">
            <h2>O aplikaci</h2>
            <?php include_mdfile("appinfo.md"); ?>
            <hr class="hide-separator">
       </section>

       <!-- What's new -->

       <section class="content-articles" id="home-news">
           <h2>Novinky</h2>
           <article>
               <?php include_mdfile("changelog.md"); ?>
           </article>
           <hr class="hide-separator">
       </section>
    </main>

    <!-- Footer -->
    <footer id="bottombar">
        <?php include("views/static/_footer.php"); ?>
    </footer>
    <script>
    <!--
        load();
    -->
    </script>
</body>
</html>