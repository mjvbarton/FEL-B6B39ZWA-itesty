<?php
    function get_header(string $menu = null)
    {
?>
<nav class="menu-top" id="topbar">
        <!-- Website name with logo -->
        <div id="logo">
            <a href="/">
                <img src="/resources/img/logo_text_white.png" alt="iTesty logo">
            </a>
            <hr class="hide-separator"/>
        </div>

        <!-- Content of menu -->
        <div id="topmenu">
            <h2>Hlavní menu</h2>
            <ul>
                <?php 
                if($menu)
                {
                    include_once("views/menu/$menu.php"); 
                }                
                ?>
            </ul>
            <hr class="hide-separator" />
        </div>
</nav>
<?php  }