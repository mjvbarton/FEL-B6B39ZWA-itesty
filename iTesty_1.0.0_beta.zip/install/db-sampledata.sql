-- phpMyAdmin SQL Dump
-- version 4.4.4
-- http://www.phpmyadmin.net
--
-- Počítač: innodb.endora.cz:3306
-- Vytvořeno: Úte 15. led 2019, 21:52
-- Verze serveru: 5.6.41-84.1
-- Verze PHP: 5.4.45

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databáze: `itesty1`
--

--
-- Vyprázdnit tabulku před vkládáním `groups`
--

TRUNCATE TABLE `groups`;
--
-- Vypisuji data pro tabulku `groups`
--

INSERT INTO `groups` (`gid`, `group_name`) VALUES
(0, 'void');

--
-- Vyprázdnit tabulku před vkládáním `institutions`
--

TRUNCATE TABLE `institutions`;
--
-- Vypisuji data pro tabulku `institutions`
--

INSERT INTO `institutions` (`iid`, `Name`, `Address`, `time_created`, `enabled`) VALUES
(0, 'Fictive institution', NULL, '2019-01-14 00:57:14', 1),
(1, 'Testovací instituce', NULL, '2019-01-15 00:40:13', 1);

--
-- Vyprázdnit tabulku před vkládáním `questions`
--

TRUNCATE TABLE `questions`;
--
-- Vypisuji data pro tabulku `questions`
--

INSERT INTO `questions` (`qid`, `toid`, `creator_uid`, `time_created`, `time_updated`, `heading`, `description`, `answer_type`, `answer_right`, `answer_count`, `answer1`, `answer2`, `answer3`, `answer4`, `answer5`, `enabled`, `public`, `valid`) VALUES
(1, 1, 0, '2019-01-15 15:26:20', '2019-01-15 15:26:20', 'Jak se nazývá slavná dvojice kutilů?', '', 'opt_text', 2, 4, 'Štaflík a Špagetka', 'Pat a Mat', 'Bob a Bobek', 'Mach a Šebestová', NULL, 1, 1, 0),
(2, 1, 0, '2019-01-15 15:31:26', '2019-01-15 15:31:26', 'Maxipes Fík přestal růst poté, co:', '', 'opt_text', 3, 5, 'snědl bramborovou kaši', 'odešel do světa', 'vypil sud piva', 'co dokončil školu', 'chytil zajíce', 1, 1, 0),
(3, 1, 0, '2019-01-15 18:58:03', '2019-01-15 18:58:03', 'Jak se jmenuje dvojník Křemílka?', 'Pozor na správný pravopis velkých písmen.', 'text', 1, 1, 'Vochomůrka', NULL, NULL, NULL, NULL, 1, 1, 0),
(4, 1, 0, '2019-01-15 19:18:50', '2019-01-15 19:18:50', 'Na čem létal Jonáš?', '', 'opt_text', 4, 4, 'na drakovi Bonifácovi', 'letadélkem Kánětem', 'na koštěti, byl to čaroděj', 'na peřině jménem Kanafásek', NULL, 1, 1, 0),
(5, 1, 0, '2019-01-15 19:20:43', '2019-01-15 19:20:43', 'Jak se jmenovala panička Maxipsa Fíka?', 'Pozor na správný pravopis velkých písmen.', 'text', 1, 1, 'Ája', NULL, NULL, NULL, NULL, 1, 1, 0),
(6, 1, 0, '2019-01-15 19:23:44', '2019-01-15 19:23:44', 'Odkud byl Eda?', 'Pokud nevíte, vzpomeňte si na Krysáky.', 'opt_text', 1, 3, 'z Prahy', 'z Bratislavy', 'z Brna', NULL, NULL, 1, 1, 0),
(7, 1, 0, '2019-01-15 19:25:31', '2019-01-15 19:25:31', 'Koho nabaloval motýl Emanuel?', '', 'opt_text', 3, 3, 'Vílu Amálku', 'Máničku', 'Makovou panenku', NULL, NULL, 1, 1, 0),
(8, 1, 0, '2019-01-15 19:26:12', '2019-01-15 19:26:12', 'Jak se jmenoval Hurvínkův pes?', 'Pozor na správný pravopis velkých písmen.', 'text', 1, 1, 'Žeryk', NULL, NULL, NULL, NULL, 1, 1, 0),
(9, 1, 0, '2019-01-15 19:27:45', '2019-01-15 19:27:45', 'Jak se jmenovali včelí medvídci?', '', 'opt_text', 2, 4, 'Čmelda a Brunďa', 'Čmelda a Brunda', 'Čmejla a Bunda', 'Čurda a Brunda', NULL, 1, 1, 0),
(10, 1, 0, '2019-01-15 19:29:59', '2019-01-15 19:29:59', 'Jak se jmenoval záporák z včelích medvíků?', 'Pozor na správný pravopis velkých písmen.', 'text', 1, 1, 'Pučmeloud', NULL, NULL, NULL, NULL, 1, 1, 0),
(11, 1, 0, '2019-01-15 19:33:48', '2019-01-15 19:33:48', 'Kdo nakreslil Krtečka?', 'Napište jméno i příjmení. Pozor na správný pravopis velkých písmen.', 'text', 1, 1, 'Zdeněk Miller', NULL, NULL, NULL, NULL, 1, 1, 0),
(12, 1, 0, '2019-01-15 19:42:50', '2019-01-15 19:42:50', 'Která dvojice je známá tím, že vařila povidla?', '', 'opt_text', 5, 5, 'Pejsek a Kočička', 'Pat a Mat', 'Káťa a Škubánek', 'Štaflík a Špagetka', 'Křemílek a Vochomůrka', 1, 1, 0),
(13, 4, 0, '2019-01-15 19:47:12', '2019-01-15 19:47:12', 'Jak se jmenuje nejdelší řeka na světě?', 'Pozor na správný pravopis velkých písmen.', 'text', 1, 1, 'Amazonka', NULL, NULL, NULL, NULL, 1, 1, 0),
(14, 4, 0, '2019-01-15 19:48:43', '2019-01-15 19:48:43', 'Jak se jmenuje nejvyšší hora Evropy?', '', 'opt_text', 5, 5, 'Elbrus', 'Matterhorn', 'Grossglockner', 'Monte Rosa', 'Mont Blanc', 1, 1, 0),
(15, 4, 0, '2019-01-15 19:48:43', '2019-01-15 19:53:04', 'Jak se jmenuje nejvyšší hora Švýcarska?', '', 'opt_text', 4, 5, 'Elbrus', 'Matterhorn', 'Grossglockner', 'Monte Rosa', 'Mont Blanc', 1, 1, 0),
(16, 4, 0, '2019-01-15 19:49:20', '2019-01-15 19:49:20', 'Jak se jmenuje nejvyšší hora Německa?', '', 'opt_text', 2, 3, 'Grossglockner', 'Zugspitze', 'Matterhorn', NULL, NULL, 1, 1, 0),
(17, 4, 0, '2019-01-15 19:50:22', '2019-01-15 19:50:22', 'Kde leží Mariánský příkop?', '', 'opt_text', 1, 4, 'v Tichém oceánu', 'v Severním ledovém oceánu', 'v USA', 'u pobřeží Antarktidy', NULL, 1, 1, 0),
(18, 4, 0, '2019-01-15 19:51:59', '2019-01-15 19:51:59', 'Jak se jmenuje největší stát na světě?', 'Doplňte jednoslovný název. Pozor na správný pravopis velkých písmen.', 'text', 1, 1, 'Rusko', NULL, NULL, NULL, NULL, 1, 1, 0),
(19, 4, 0, '2019-01-15 19:54:42', '2019-01-15 19:54:42', 'V Asii neleží stát:', '', 'opt_text', 2, 4, 'Angola', 'Sýrie', 'Súdán', 'Lybie', NULL, 1, 1, 0),
(20, 4, 0, '2019-01-15 19:56:17', '2019-01-15 19:56:17', 'Kde najdeme Pyrenejský poloostrov?', '', 'opt_text', 1, 4, 'v Evropě', 'v Asii', 'v Americe', 'takový poloostrov neexistuje', NULL, 1, 1, 0),
(21, 10, 0, '2019-01-15 19:58:29', '2019-01-15 19:58:29', 'Kdo napsal dílo Symphonia Fantastica?', 'Napište jméno a příjmení. Pište bez diakritiky a pozor na správný pravopis velkých písmen.', 'text', 1, 1, 'Henri Berlioz', NULL, NULL, NULL, NULL, 1, 1, 0),
(22, 10, 0, '2019-01-15 20:00:32', '2019-01-15 20:00:32', 'Vyberte slovo s podobným významem jako leitmotiv:', '', 'opt_text', 3, 3, 'věta skladby', 'hlavní motiv celého skladatelova díla', 'idée fixe', NULL, NULL, 1, 1, 0),
(23, 10, 0, '2019-01-15 20:01:32', '2019-01-15 20:01:32', 'Jak se nazývá nejvýznamnější Wagnerova opera?', 'Pište českým názvem. Pozor na správný pravopis velkých písmen.', 'text', 1, 1, 'Prsten Nibelungův', NULL, NULL, NULL, NULL, 1, 1, 0),
(24, 10, 0, '2019-01-15 20:04:50', '2019-01-15 20:04:50', 'Vyber správného skladatele z období novoromantismu', '', 'opt_text', 4, 4, 'Bohuslav Martinů', 'Dimitrij Šostakovič', 'Robert Schumann', 'Franz Liszt', NULL, 1, 1, 0),
(25, 10, 0, '2019-01-15 20:07:42', '2019-01-15 20:07:42', 'Jaká je typická forma pro novoromantismus?', '', 'opt_text', 3, 3, 'fuga', 'sonáta', 'symfonická báseň', NULL, NULL, 1, 1, 0),
(26, 10, 0, '2019-01-15 20:10:22', '2019-01-15 20:10:22', 'Čím jsou typické Wagnerovy opery?', '', 'opt_text', 2, 4, 'byly napsány pro komorní orchestr a malý sbor', 'jedna opera je rozdělena do tří večerů', 'jsou dnes často hrány po celém světě', 'jsou krátké', NULL, 1, 1, 0);

--
-- Vyprázdnit tabulku před vkládáním `subjects`
--

TRUNCATE TABLE `subjects`;
--
-- Vypisuji data pro tabulku `subjects`
--

INSERT INTO `subjects` (`sid`, `iid`, `name`, `description`, `enabled`, `time_created`, `time_edited`) VALUES
(1, 1, 'Testování', NULL, 1, '2019-01-15 00:37:11', '2019-01-15 00:40:52'),
(2, 1, 'Dějiny hudby', NULL, 1, '2019-01-15 00:37:11', '2019-01-15 00:40:52'),
(3, 1, 'Nauka o nástrojích', NULL, 1, '2019-01-15 00:37:11', '2019-01-15 00:40:52'),
(4, 1, 'Harmonie', NULL, 1, '2019-01-15 00:37:11', '2019-01-15 00:40:52');

--
-- Vyprázdnit tabulku před vkládáním `tests`
--

TRUNCATE TABLE `tests`;
--
-- Vyprázdnit tabulku před vkládáním `test_content`
--

TRUNCATE TABLE `test_content`;
--
-- Vyprázdnit tabulku před vkládáním `topics`
--

TRUNCATE TABLE `topics`;
--
-- Vypisuji data pro tabulku `topics`
--

INSERT INTO `topics` (`toid`, `sid`, `name`, `description`, `class`, `enabled`, `time_created`, `time_edited`) VALUES
(1, 1, 'Večerníčky', '', 1, 1, '2019-01-15 13:53:30', '2019-01-15 13:54:51'),
(2, 1, 'Všeobecné znalosti', '', 2, 1, '2019-01-15 13:53:30', '2019-01-15 13:54:51'),
(3, 1, 'Vánoce', '', 1, 1, '2019-01-15 13:53:30', '2019-01-15 13:54:51'),
(4, 1, 'Světový zeměpis', '', 3, 1, '2019-01-15 13:53:30', '2019-01-15 13:54:51'),
(5, 2, 'Starověk a středověk', '', 1, 1, '2019-01-15 13:53:30', '2019-01-15 13:53:30'),
(6, 2, 'Renesance', '', 1, 1, '2019-01-15 13:53:30', '2019-01-15 13:54:51'),
(7, 2, 'Baroko', '', 1, 1, '2019-01-15 13:53:30', '2019-01-15 13:54:51'),
(8, 2, 'Klasicisimus', '', 1, 1, '2019-01-15 13:53:30', '2019-01-15 13:54:51'),
(9, 2, 'Romantismus', '', 2, 2, '2019-01-15 13:53:30', '2019-01-15 13:53:30'),
(10, 2, 'Novoromantismus', '', 4, 1, '2019-01-15 13:53:30', '2019-01-15 13:53:30'),
(11, 2, 'Přelom století', '', 4, 1, '2019-01-15 13:53:30', '2019-01-15 13:56:19'),
(12, 2, 'Moderní hudba', '', 5, 1, '2019-01-15 13:53:30', '2019-01-15 13:56:19'),
(13, 2, 'J. S. Bach', '', 1, 1, '2019-01-15 13:53:30', '2019-01-15 13:56:19'),
(14, 2, 'Maturitní otázky', '', 4, 1, '2019-01-15 13:53:30', '2019-01-15 13:56:19'),
(15, 2, 'Česká hudba 20. století', '', 5, 1, '2019-01-15 13:59:35', '2019-01-15 13:59:35'),
(16, 2, 'Periodizace dějin hudby', '', 1, 1, '2019-01-15 13:59:35', '2019-01-15 13:59:35');

--
-- Vyprázdnit tabulku před vkládáním `users`
--

TRUNCATE TABLE `users`;
--
-- Vypisuji data pro tabulku `users`
--

INSERT INTO `users` (`uid`, `usermail`, `userpw`, `First_name`, `Family_name`, `time_created`, `time_edited`, `gid`, `iid`, `ban`, `sso_token`) VALUES
(0, 'admin@itesty.mjvbarton.cz', '$2y$10$O2SL1wTysD3aHCSaMB0sQuv4v/wV2PNBV.8z3qfQiziisZI6FobXm', 'Správce', 'systému', '2019-01-14 01:05:20', '2019-01-14 20:21:56', 0, 0, 0, NULL);

--
-- Vyprázdnit tabulku před vkládáním `user_answers`
--

TRUNCATE TABLE `user_answers`;
--
-- Vypisuji data pro tabulku `user_answers`
--

INSERT INTO `user_answers` (`uaid`, `value`, `time_created`) VALUES
(0, NULL, '2019-01-14 01:01:30');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
